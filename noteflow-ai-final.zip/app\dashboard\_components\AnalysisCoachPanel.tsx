"use client";

import { useMemo, useState } from "react";
import type { SavedAnalysis } from "../_lib/types";
import UpgradeModal from "../../components/UpgradeModal";
import { usePro } from "../../lib/pro/usePro";

type CoachMode = "simplify" | "hard-questions" | "oral-exam" | "quick-revision";

type AnalysisCoachPanelProps = {
  analysis: SavedAnalysis;
};

const modes: Array<{
  id: CoachMode;
  label: string;
  proOnly?: boolean;
}> = [
  { id: "simplify", label: "Wyjaśnij prościej" },
  { id: "hard-questions", label: "Trudniejsze pytania", proOnly: true },
  { id: "oral-exam", label: "Egzamin ustny", proOnly: true },
  { id: "quick-revision", label: "Szybka powtórka", proOnly: true },
];

export default function AnalysisCoachPanel({
  analysis,
}: AnalysisCoachPanelProps) {
  const [mode, setMode] = useState<CoachMode>("simplify");
  const [showUpgrade, setShowUpgrade] = useState(false);
  const { isPro, hydrated } = usePro();

  const coachOutput = useMemo(() => {
    const { result } = analysis;

    if (mode === "simplify") {
      return {
        title: "Prostsze wyjaśnienie materiału",
        intro:
          "Ta wersja upraszcza główne idee i skupia się na tym, co naprawdę trzeba zrozumieć.",
        items: [
          `Najważniejsza myśl tego materiału: ${result.summary}`,
          ...result.keyTakeaways
            .slice(0, 4)
            .map((item, index) => `Kluczowy punkt ${index + 1}: ${item}`),
          ...result.concepts
            .slice(0, 3)
            .map(
              (concept) =>
                `Zapamiętaj pojęcie „${concept}” jako jeden z fundamentów tego tematu.`
            ),
        ],
      };
    }

    if (mode === "hard-questions") {
      return {
        title: "Trudniejsze pytania do materiału",
        intro:
          "Te pytania mają zmusić Cię do głębszego myślenia, a nie tylko odtworzenia definicji.",
        items: result.concepts.slice(0, 5).map((concept, index) => {
          const linkedQuestion =
            result.questions[index % Math.max(result.questions.length, 1)] ??
            "Jak uzasadnisz znaczenie tego zagadnienia?";
          return `Jak pojęcie „${concept}” łączy się z pytaniem: ${linkedQuestion}`;
        }),
      };
    }

    if (mode === "oral-exam") {
      return {
        title: "Symulacja egzaminu ustnego",
        intro:
          "Odpowiadaj pełnymi zdaniami, tak jak na zaliczeniu lub egzaminie ustnym.",
        items: [
          ...result.questions
            .slice(0, 4)
            .map((question) => `Proszę omówić: ${question}`),
          ...result.concepts
            .slice(0, 2)
            .map(
              (concept) =>
                `Proszę zdefiniować pojęcie „${concept}” i podać jego praktyczne znaczenie.`
            ),
        ],
      };
    }

    return {
      title: "Mini plan szybkiej powtórki",
      intro:
        "To krótki, konkretny plan na 10–15 minut, żeby szybko wrócić do materiału.",
      items: [
        "1. Przeczytaj streszczenie i zaznacz 2 najważniejsze idee.",
        `2. Powtórz pojęcia: ${analysis.result.concepts.slice(0, 4).join(", ")}.`,
        `3. Odpowiedz na pytania: ${analysis.result.questions
          .slice(0, 2)
          .join(" | ")}.`,
        `4. Przejrzyj fiszki: ${analysis.result.flashcards.length} kart do szybkiego utrwalenia.`,
        "5. Na koniec spróbuj własnymi słowami streścić materiał w 3 zdaniach.",
      ],
    };
  }, [analysis, mode]);

  const handleModeChange = (nextMode: CoachMode, proOnly?: boolean) => {
    if (proOnly && hydrated && !isPro) {
      setShowUpgrade(true);
      return;
    }

    setMode(nextMode);
  };

  return (
    <>
      <UpgradeModal
        open={showUpgrade}
        onClose={() => setShowUpgrade(false)}
        title="AI Coach w pełnej wersji jest w planie Pro"
        description="Tryby Trudniejsze pytania, Egzamin ustny i Szybka powtórka są dostępne w NoteFlow Pro."
        featureName="Zaawansowane tryby AI Coach"
      />

      <section className="mb-8 rounded-3xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900">
        <div className="mb-6 flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
          <div>
            <p className="text-sm text-slate-500 dark:text-slate-400">
              AI tutor workspace
            </p>
            <h2 className="text-2xl font-semibold">Panel trenera nauki</h2>
            <p className="mt-2 max-w-2xl text-sm leading-7 text-slate-600 dark:text-slate-300">
              Ten moduł pomaga wrócić do materiału z różnych perspektyw: prostszym
              językiem, trudniejszymi pytaniami, symulacją ustną i szybką powtórką.
            </p>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 dark:border-slate-800 dark:bg-slate-950">
            <p className="text-xs uppercase tracking-[0.18em] text-slate-500 dark:text-slate-400">
              Active mode
            </p>
            <p className="mt-2 text-lg font-semibold">{coachOutput.title}</p>
          </div>
        </div>

        <div className="mb-6 flex flex-wrap gap-2">
          {modes.map((item) => {
            const locked = item.proOnly && hydrated && !isPro;

            return (
              <button
                key={item.id}
                type="button"
                onClick={() => handleModeChange(item.id, item.proOnly)}
                className={`rounded-2xl px-4 py-2 text-sm font-medium transition ${
                  mode === item.id
                    ? "bg-slate-950 text-white dark:bg-white dark:text-slate-950"
                    : "border border-slate-300 bg-white hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:hover:bg-slate-800"
                }`}
              >
                {item.label}
                {locked ? " · Pro" : ""}
              </button>
            );
          })}
        </div>

        <div className="rounded-3xl border border-slate-200 bg-slate-50 p-6 dark:border-slate-800 dark:bg-slate-950">
          <h3 className="text-xl font-semibold">{coachOutput.title}</h3>
          <p className="mt-3 text-sm leading-7 text-slate-600 dark:text-slate-300">
            {coachOutput.intro}
          </p>

          <div className="mt-5 space-y-3">
            {coachOutput.items.map((item, index) => (
              <div
                key={`${mode}-${index}`}
                className="rounded-2xl border border-slate-200 bg-white p-4 text-sm leading-7 text-slate-700 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300"
              >
                {item}
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
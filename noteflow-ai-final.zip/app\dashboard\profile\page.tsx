"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "../../lib/supabase/client";
import type {
  ProfileRow,
  UserStatsRow,
} from "../../lib/supabase/types";

export default function ProfilePage() {
  const supabase = useMemo(() => createClient(), []);
  const router = useRouter();

  const [profile, setProfile] = useState<ProfileRow | null>(null);
  const [stats, setStats] = useState<UserStatsRow | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");

  useEffect(() => {
    let active = true;

    async function loadProfile() {
      const {
        data: { user },
        error: userError,
      } = await supabase.auth.getUser();

      if (userError || !user) {
        router.push("/login");
        return;
      }

      const [profileResult, statsResult] = await Promise.all([
        supabase.from("profiles").select("*").eq("id", user.id).single(),
        supabase.from("user_stats").select("*").eq("user_id", user.id).single(),
      ]);

      if (!active) {
        return;
      }

      if (profileResult.error) {
        setMessage("Nie udało się pobrać profilu.");
      } else {
        setProfile(profileResult.data);
      }

      if (!statsResult.error) {
        setStats(statsResult.data);
      }

      setLoading(false);
    }

    loadProfile();

    return () => {
      active = false;
    };
  }, [router, supabase]);

  async function handleSave() {
    if (!profile) {
      return;
    }

    setSaving(true);
    setMessage("");

    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      router.push("/login");
      return;
    }

    const { error } = await supabase
      .from("profiles")
      .update({
        full_name: profile.full_name.trim(),
        bio: profile.bio,
        learning_style: profile.learning_style,
        daily_goal_minutes: profile.daily_goal_minutes,
        updated_at: new Date().toISOString(),
      })
      .eq("id", user.id);

    setSaving(false);

    if (error) {
      setMessage("Nie udało się zapisać profilu.");
      return;
    }

    setMessage("Profil został zapisany.");
  }

  async function handleLogout() {
    await supabase.auth.signOut();
    router.push("/login");
    router.refresh();
  }

  if (loading) {
    return (
      <main className="min-h-screen bg-slate-50 px-4 py-10">
        <div className="mx-auto max-w-6xl rounded-[28px] border border-slate-200 bg-white p-8 shadow-sm">
          Ładowanie profilu...
        </div>
      </main>
    );
  }

  if (!profile) {
    return (
      <main className="min-h-screen bg-slate-50 px-4 py-10">
        <div className="mx-auto max-w-6xl rounded-[28px] border border-slate-200 bg-white p-8 shadow-sm">
          Nie udało się wczytać profilu.
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-slate-50 px-4 py-10">
      <div className="mx-auto grid max-w-6xl gap-6 lg:grid-cols-[1.3fr_0.7fr]">
        <section className="rounded-[28px] border border-slate-200 bg-white p-8 shadow-sm">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div>
              <p className="text-sm font-medium text-slate-500">User profile</p>
              <h1 className="mt-1 text-3xl font-bold tracking-tight text-slate-900">
                {profile.full_name || "Nowy użytkownik"}
              </h1>
              <p className="mt-2 text-sm text-slate-600">{profile.email}</p>
            </div>

            <button
              type="button"
              onClick={handleLogout}
              className="rounded-2xl border border-slate-300 px-4 py-2 text-sm font-medium text-slate-700 transition hover:bg-slate-50"
            >
              Wyloguj
            </button>
          </div>

          <div className="mt-8 grid gap-5 md:grid-cols-2">
            <div>
              <label className="mb-2 block text-sm font-medium text-slate-700">
                Imię i nazwisko
              </label>
              <input
                value={profile.full_name}
                onChange={(e) =>
                  setProfile((prev) =>
                    prev ? { ...prev, full_name: e.target.value } : prev
                  )
                }
                className="h-12 w-full rounded-2xl border border-slate-300 px-4 outline-none transition focus:border-slate-500"
              />
            </div>

            <div>
              <label className="mb-2 block text-sm font-medium text-slate-700">
                Email
              </label>
              <input
                value={profile.email}
                disabled
                className="h-12 w-full rounded-2xl border border-slate-200 bg-slate-100 px-4 text-slate-500"
              />
            </div>

            <div>
              <label className="mb-2 block text-sm font-medium text-slate-700">
                Styl nauki
              </label>
              <select
                value={profile.learning_style}
                onChange={(e) =>
                  setProfile((prev) =>
                    prev
                      ? {
                          ...prev,
                          learning_style: e.target.value as ProfileRow["learning_style"],
                        }
                      : prev
                  )
                }
                className="h-12 w-full rounded-2xl border border-slate-300 px-4 outline-none transition focus:border-slate-500"
              >
                <option value="mixed">Mixed</option>
                <option value="quiz">Quiz</option>
                <option value="flashcards">Flashcards</option>
                <option value="notes">Notes</option>
              </select>
            </div>

            <div>
              <label className="mb-2 block text-sm font-medium text-slate-700">
                Dzienny cel (min)
              </label>
              <input
                type="number"
                min={0}
                value={profile.daily_goal_minutes}
                onChange={(e) =>
                  setProfile((prev) =>
                    prev
                      ? {
                          ...prev,
                          daily_goal_minutes: Number(e.target.value) || 0,
                        }
                      : prev
                  )
                }
                className="h-12 w-full rounded-2xl border border-slate-300 px-4 outline-none transition focus:border-slate-500"
              />
            </div>
          </div>

          <div className="mt-5">
            <label className="mb-2 block text-sm font-medium text-slate-700">
              O mnie
            </label>
            <textarea
              value={profile.bio}
              onChange={(e) =>
                setProfile((prev) =>
                  prev ? { ...prev, bio: e.target.value } : prev
                )
              }
              rows={5}
              className="w-full rounded-2xl border border-slate-300 px-4 py-3 outline-none transition focus:border-slate-500"
              placeholder="Napisz kilka słów o sobie i swoim sposobie nauki..."
            />
          </div>

          <div className="mt-6 flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={handleSave}
              disabled={saving}
              className="rounded-2xl bg-slate-900 px-5 py-3 text-sm font-semibold text-white transition hover:bg-slate-800 disabled:opacity-60"
            >
              {saving ? "Zapisywanie..." : "Zapisz profil"}
            </button>

            {message ? (
              <span className="text-sm text-slate-600">{message}</span>
            ) : null}
          </div>
        </section>

        <aside className="space-y-6">
          <section className="rounded-[28px] border border-slate-200 bg-white p-6 shadow-sm">
            <p className="text-sm font-medium text-slate-500">Plan</p>
            <h2 className="mt-1 text-2xl font-bold text-slate-900">
              {profile.plan === "pro" ? "Pro" : "Free"}
            </h2>
            <p className="mt-2 text-sm text-slate-600">
              Konto aktywne od{" "}
              {new Date(profile.joined_at).toLocaleDateString("pl-PL")}
            </p>
          </section>

          <section className="rounded-[28px] border border-slate-200 bg-white p-6 shadow-sm">
            <p className="text-sm font-medium text-slate-500">Statystyki</p>

            <div className="mt-4 grid gap-3">
              <div className="rounded-2xl bg-slate-50 p-4">
                <div className="text-sm text-slate-500">Streak</div>
                <div className="text-2xl font-bold text-slate-900">
                  {stats?.streak ?? 0}
                </div>
              </div>

              <div className="rounded-2xl bg-slate-50 p-4">
                <div className="text-sm text-slate-500">Czas nauki</div>
                <div className="text-2xl font-bold text-slate-900">
                  {stats?.total_study_minutes ?? 0} min
                </div>
              </div>

              <div className="rounded-2xl bg-slate-50 p-4">
                <div className="text-sm text-slate-500">Analizy</div>
                <div className="text-2xl font-bold text-slate-900">
                  {stats?.total_analyses ?? 0}
                </div>
              </div>

              <div className="rounded-2xl bg-slate-50 p-4">
                <div className="text-sm text-slate-500">Quizy</div>
                <div className="text-2xl font-bold text-slate-900">
                  {stats?.total_quiz_attempts ?? 0}
                </div>
              </div>
            </div>
          </section>
        </aside>
      </div>
    </main>
  );
}
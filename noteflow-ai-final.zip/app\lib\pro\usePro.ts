"use client";

import { useEffect, useState } from "react";

const STORAGE_KEY = "noteflow-pro";
const SESSION_KEY = "noteflow-pro-session";

type StoredProState = {
  isPro: boolean;
  source: "local" | "stripe";
  sessionId?: string;
  updatedAt: string;
};

function readStoredState(): StoredProState | null {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);

    if (!raw) return null;

    const parsed = JSON.parse(raw) as StoredProState;

    if (typeof parsed !== "object" || parsed === null) return null;

    return {
      isPro: Boolean(parsed.isPro),
      source: parsed.source === "stripe" ? "stripe" : "local",
      sessionId:
        typeof parsed.sessionId === "string" ? parsed.sessionId : undefined,
      updatedAt:
        typeof parsed.updatedAt === "string"
          ? parsed.updatedAt
          : new Date().toISOString(),
    };
  } catch {
    return null;
  }
}

function writeStoredState(value: StoredProState) {
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(value));
  } catch {}
}

export function usePro() {
  const [isPro, setIsPro] = useState(false);
  const [hydrated, setHydrated] = useState(false);
  const [syncing, setSyncing] = useState(false);

  useEffect(() => {
    let cancelled = false;

    async function boot() {
      try {
        const stored = readStoredState();

        if (stored && !cancelled) {
          setIsPro(stored.isPro);
        }

        const url = new URL(window.location.href);
        const upgrade = url.searchParams.get("upgrade");
        const sessionId = url.searchParams.get("session_id");

        if (upgrade === "success" && sessionId) {
          setSyncing(true);

          const res = await fetch("/api/stripe/verify-session", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({ sessionId }),
          });

          const data = (await res.json()) as {
            isPro?: boolean;
            error?: string;
          };

          if (!cancelled && res.ok && data.isPro) {
            setIsPro(true);

            writeStoredState({
              isPro: true,
              source: "stripe",
              sessionId,
              updatedAt: new Date().toISOString(),
            });

            try {
              window.sessionStorage.setItem(SESSION_KEY, sessionId);
            } catch {}
          }

          url.searchParams.delete("upgrade");
          url.searchParams.delete("session_id");
          window.history.replaceState({}, "", url.toString());
        }
      } catch (error) {
        console.error("[usePro] boot error", error);
      } finally {
        if (!cancelled) {
          setHydrated(true);
          setSyncing(false);
        }
      }
    }

    void boot();

    return () => {
      cancelled = true;
    };
  }, []);

  const enablePro = (sessionId?: string) => {
    const payload: StoredProState = {
      isPro: true,
      source: sessionId ? "stripe" : "local",
      sessionId,
      updatedAt: new Date().toISOString(),
    };

    writeStoredState(payload);
    setIsPro(true);

    if (sessionId) {
      try {
        window.sessionStorage.setItem(SESSION_KEY, sessionId);
      } catch {}
    }
  };

  const disablePro = () => {
    try {
      window.localStorage.removeItem(STORAGE_KEY);
      window.sessionStorage.removeItem(SESSION_KEY);
    } catch {}

    setIsPro(false);
  };

  const refreshFromStripeSession = async (sessionId: string) => {
    setSyncing(true);

    try {
      const res = await fetch("/api/stripe/verify-session", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ sessionId }),
      });

      const data = (await res.json()) as {
        isPro?: boolean;
        error?: string;
      };

      if (!res.ok) {
        throw new Error(data.error || "Nie udało się odświeżyć statusu Pro.");
      }

      if (data.isPro) {
        enablePro(sessionId);
      } else {
        disablePro();
      }

      return Boolean(data.isPro);
    } finally {
      setSyncing(false);
    }
  };

  return {
    isPro,
    hydrated,
    syncing,
    enablePro,
    disablePro,
    refreshFromStripeSession,
  };
}
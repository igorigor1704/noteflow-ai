
"use client";

import {
  learningGoalOptions,
  learningStyleOptions,
  type StudyPreferences,
} from "../_lib/preferences";

type OnboardingModalProps = {
  isOpen: boolean;
  draft: StudyPreferences;
  onChange: <K extends keyof StudyPreferences>(
    key: K,
    value: StudyPreferences[K]
  ) => void;
  onSubmit: () => void;
};

export default function OnboardingModal({
  isOpen,
  draft,
  onChange,
  onSubmit,
}: OnboardingModalProps) {
  if (!isOpen) return null;

  const selectedLearningStyle =
    learningStyleOptions.find((option) => option.value === draft.learningStyle)
      ?.label ?? draft.learningStyle;

  const selectedLearningGoal =
    learningGoalOptions.find((option) => option.value === draft.learningGoal)
      ?.label ?? draft.learningGoal;

  return (
    <div className="fixed inset-0 z-[9999] overflow-y-auto bg-slate-900/40 backdrop-blur-sm">
      <div className="min-h-screen px-4 py-6 md:px-6 md:py-10">
        <div className="mx-auto grid w-full max-w-6xl gap-6 xl:grid-cols-[minmax(0,1.35fr)_360px]">
          <section className="rounded-[32px] border border-slate-200 bg-white p-6 shadow-2xl md:p-8 xl:p-10">
            <div className="mb-8">
              <div className="mb-4 flex flex-wrap items-center gap-3">
                <span className="rounded-full border border-indigo-200 bg-indigo-50 px-3 py-1 text-[11px] font-bold uppercase tracking-[0.2em] text-indigo-700">
                  NoteFlow setup
                </span>
                <span className="rounded-full border border-slate-200 bg-slate-50 px-3 py-1 text-xs font-medium text-slate-500">
                  Personalizacja nauki
                </span>
              </div>

              <h2 className="text-3xl font-extrabold tracking-tight text-slate-900 md:text-5xl">
                Skonfiguruj swój system nauki
              </h2>

              <p className="mt-4 max-w-3xl text-sm leading-7 text-slate-600 md:text-base">
                Ustawimy cele i preferencje, żeby dashboard, smart queue, focus
                timer i rekomendacje działały dokładnie pod Twój styl nauki.
              </p>
            </div>

            <div className="grid gap-5">
              <div className="grid gap-5 md:grid-cols-2">
                <div>
                  <label
                    htmlFor="displayName"
                    className="mb-2 block text-sm font-semibold text-slate-700"
                  >
                    Jak mam się do Ciebie zwracać?
                  </label>
                  <input
                    id="displayName"
                    type="text"
                    placeholder="Np. Maja"
                    value={draft.displayName}
                    onChange={(e) => onChange("displayName", e.target.value)}
                    className="h-14 w-full rounded-2xl border border-slate-200 bg-white px-4 text-slate-900 outline-none transition focus:border-indigo-500 focus:ring-4 focus:ring-indigo-100"
                  />
                </div>

                <div>
                  <label
                    htmlFor="primaryFocus"
                    className="mb-2 block text-sm font-semibold text-slate-700"
                  >
                    Główny obszar nauki
                  </label>
                  <input
                    id="primaryFocus"
                    type="text"
                    placeholder="Np. finanse, ekonomia, statystyka"
                    value={draft.primaryFocus}
                    onChange={(e) => onChange("primaryFocus", e.target.value)}
                    className="h-14 w-full rounded-2xl border border-slate-200 bg-white px-4 text-slate-900 outline-none transition focus:border-indigo-500 focus:ring-4 focus:ring-indigo-100"
                  />
                </div>
              </div>

              <div className="grid gap-5 md:grid-cols-2">
                <div>
                  <label
                    htmlFor="dailyGoalMinutes"
                    className="mb-2 block text-sm font-semibold text-slate-700"
                  >
                    Cel dzienny
                  </label>
                  <input
                    id="dailyGoalMinutes"
                    type="number"
                    min={5}
                    step={5}
                    value={draft.dailyGoalMinutes}
                    onChange={(e) =>
                      onChange("dailyGoalMinutes", Number(e.target.value) || 25)
                    }
                    className="h-14 w-full rounded-2xl border border-slate-200 bg-white px-4 text-slate-900 outline-none transition focus:border-indigo-500 focus:ring-4 focus:ring-indigo-100"
                  />
                  <p className="mt-2 text-xs text-slate-500">
                    Minuty nauki dziennie
                  </p>
                </div>

                <div>
                  <label
                    htmlFor="weeklyTargetSessions"
                    className="mb-2 block text-sm font-semibold text-slate-700"
                  >
                    Cel tygodniowy
                  </label>
                  <input
                    id="weeklyTargetSessions"
                    type="number"
                    min={1}
                    step={1}
                    value={draft.weeklyTargetSessions}
                    onChange={(e) =>
                      onChange(
                        "weeklyTargetSessions",
                        Number(e.target.value) || 5
                      )
                    }
                    className="h-14 w-full rounded-2xl border border-slate-200 bg-white px-4 text-slate-900 outline-none transition focus:border-indigo-500 focus:ring-4 focus:ring-indigo-100"
                  />
                  <p className="mt-2 text-xs text-slate-500">
                    Liczba sesji tygodniowo
                  </p>
                </div>
              </div>

              <div className="grid gap-5 md:grid-cols-2">
                <div>
                  <label
                    htmlFor="preferredSessionLength"
                    className="mb-2 block text-sm font-semibold text-slate-700"
                  >
                    Preferowana długość sesji
                  </label>
                  <select
                    id="preferredSessionLength"
                    value={String(draft.preferredSessionLength)}
                    onChange={(e) =>
                      onChange(
                        "preferredSessionLength",
                        Number(
                          e.target.value
                        ) as StudyPreferences["preferredSessionLength"]
                      )
                    }
                    className="h-14 w-full rounded-2xl border border-slate-200 bg-white px-4 text-slate-900 outline-none transition focus:border-indigo-500 focus:ring-4 focus:ring-indigo-100"
                  >
                    <option value="15">15 min</option>
                    <option value="25">25 min</option>
                    <option value="45">45 min</option>
                    <option value="60">60 min</option>
                  </select>
                </div>

                <div>
                  <label
                    htmlFor="learningStyle"
                    className="mb-2 block text-sm font-semibold text-slate-700"
                  >
                    Styl nauki
                  </label>
                  <select
                    id="learningStyle"
                    value={draft.learningStyle}
                    onChange={(e) =>
                      onChange(
                        "learningStyle",
                        e.target.value as StudyPreferences["learningStyle"]
                      )
                    }
                    className="h-14 w-full rounded-2xl border border-slate-200 bg-white px-4 text-slate-900 outline-none transition focus:border-indigo-500 focus:ring-4 focus:ring-indigo-100"
                  >
                    {learningStyleOptions.map((option) => (
                      <option key={option.value} value={option.value}>
                        {option.label}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label
                  htmlFor="learningGoal"
                  className="mb-2 block text-sm font-semibold text-slate-700"
                >
                  Jaki jest Twój cel nauki?
                </label>
                <select
                  id="learningGoal"
                  value={draft.learningGoal}
                  onChange={(e) =>
                    onChange(
                      "learningGoal",
                      e.target.value as StudyPreferences["learningGoal"]
                    )
                  }
                  className="h-14 w-full rounded-2xl border border-slate-200 bg-white px-4 text-slate-900 outline-none transition focus:border-indigo-500 focus:ring-4 focus:ring-indigo-100"
                >
                  {learningGoalOptions.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <label className="flex items-start justify-between gap-4 rounded-2xl border border-slate-200 bg-slate-50 p-4">
                  <div>
                    <div className="text-sm font-bold text-slate-900">
                      Powiadomienia
                    </div>
                    <div className="mt-1 text-sm leading-6 text-slate-600">
                      Otrzymuj przypomnienia o nauce i sesjach.
                    </div>
                  </div>
                  <input
                    type="checkbox"
                    checked={draft.notificationsEnabled}
                    onChange={(e) =>
                      onChange("notificationsEnabled", e.target.checked)
                    }
                    className="mt-1 h-5 w-5 accent-indigo-600"
                  />
                </label>

                <label className="flex items-start justify-between gap-4 rounded-2xl border border-slate-200 bg-slate-50 p-4">
                  <div>
                    <div className="text-sm font-bold text-slate-900">
                      Auto start focus
                    </div>
                    <div className="mt-1 text-sm leading-6 text-slate-600">
                      Automatycznie uruchamiaj sesję focus.
                    </div>
                  </div>
                  <input
                    type="checkbox"
                    checked={draft.autoStartFocus}
                    onChange={(e) => onChange("autoStartFocus", e.target.checked)}
                    className="mt-1 h-5 w-5 accent-indigo-600"
                  />
                </label>
              </div>

              <label className="flex items-start justify-between gap-4 rounded-2xl border border-slate-200 bg-slate-50 p-4">
                <div>
                  <div className="text-sm font-bold text-slate-900">
                    Pokazuj wskazówki
                  </div>
                  <div className="mt-1 text-sm leading-6 text-slate-600">
                    Wyświetlaj krótkie podpowiedzi przy pierwszym korzystaniu z
                    dashboardu.
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={draft.showOnboardingTips}
                  onChange={(e) =>
                    onChange("showOnboardingTips", e.target.checked)
                  }
                  className="mt-1 h-5 w-5 accent-indigo-600"
                />
              </label>

              <div className="xl:hidden">
                <button
                  type="button"
                  onClick={onSubmit}
                  className="w-full rounded-2xl bg-indigo-600 px-6 py-4 text-base font-bold text-white transition hover:bg-indigo-500"
                >
                  Zapisz i przejdź do dashboardu
                </button>
              </div>
            </div>
          </section>

          <aside className="rounded-[32px] border border-slate-200 bg-white p-6 shadow-2xl xl:sticky xl:top-8 xl:h-fit">
            <div className="mb-4 inline-flex rounded-full border border-indigo-200 bg-indigo-50 px-3 py-1 text-[11px] font-bold uppercase tracking-[0.2em] text-indigo-700">
              Twój profil
            </div>

            <h3 className="text-2xl font-bold tracking-tight text-slate-900">
              Personalizacja dashboardu
            </h3>
            <p className="mt-3 text-sm leading-7 text-slate-600">
              NoteFlow dopasuje rytm pracy, rekomendacje i układ sesji do Twoich
              preferencji.
            </p>

            <div className="mt-6 grid gap-3">
              <div className="flex items-center justify-between gap-3 rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3">
                <span className="text-sm text-slate-500">Imię</span>
                <span className="text-right text-sm font-bold text-slate-900">
                  {draft.displayName || "Nie ustawiono"}
                </span>
              </div>

              <div className="flex items-center justify-between gap-3 rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3">
                <span className="text-sm text-slate-500">Obszar</span>
                <span className="text-right text-sm font-bold text-slate-900">
                  {draft.primaryFocus || "Nie ustawiono"}
                </span>
              </div>

              <div className="flex items-center justify-between gap-3 rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3">
                <span className="text-sm text-slate-500">Cel dzienny</span>
                <span className="text-right text-sm font-bold text-slate-900">
                  {draft.dailyGoalMinutes} min
                </span>
              </div>

              <div className="flex items-center justify-between gap-3 rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3">
                <span className="text-sm text-slate-500">Cel tygodniowy</span>
                <span className="text-right text-sm font-bold text-slate-900">
                  {draft.weeklyTargetSessions} sesji
                </span>
              </div>

              <div className="flex items-center justify-between gap-3 rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3">
                <span className="text-sm text-slate-500">Sesja</span>
                <span className="text-right text-sm font-bold text-slate-900">
                  {draft.preferredSessionLength} min
                </span>
              </div>

              <div className="flex items-center justify-between gap-3 rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3">
                <span className="text-sm text-slate-500">Styl</span>
                <span className="text-right text-sm font-bold text-slate-900">
                  {selectedLearningStyle}
                </span>
              </div>

              <div className="flex items-center justify-between gap-3 rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3">
                <span className="text-sm text-slate-500">Cel</span>
                <span className="text-right text-sm font-bold text-slate-900">
                  {selectedLearningGoal}
                </span>
              </div>
            </div>

            <button
              type="button"
              onClick={onSubmit}
              className="mt-6 hidden w-full rounded-2xl bg-indigo-600 px-6 py-4 text-base font-bold text-white transition hover:bg-indigo-500 xl:block"
            >
              Zapisz i przejdź do dashboardu
            </button>

            <p className="mt-4 text-center text-xs text-slate-500">
              Te ustawienia możesz później zmienić w profilu.
            </p>
          </aside>
        </div>
      </div>
    </div>
  );
}
import { NextResponse } from "next/server";

const MAX_QUESTION_LENGTH = 3000;
const MIN_QUESTION_LENGTH = 5;

function sanitize(value: string) {
  return value.replace(/\u0000/g, "").replace(/\s+/g, " ").trim();
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const question =
      typeof body.question === "string" ? sanitize(body.question) : "";

    if (!question) {
      return NextResponse.json({ error: "Brak pytania." }, { status: 400 });
    }

    if (question.length < MIN_QUESTION_LENGTH) {
      return NextResponse.json(
        { error: "Pytanie jest za krótkie." },
        { status: 400 }
      );
    }

    if (question.length > MAX_QUESTION_LENGTH) {
      return NextResponse.json(
        {
          error: `Pytanie jest za długie. Maksymalnie ${MAX_QUESTION_LENGTH} znaków.`,
        },
        { status: 400 }
      );
    }

    if (!process.env.OPENAI_API_KEY) {
      return NextResponse.json(
        { error: "Brak OPENAI_API_KEY w .env.local" },
        { status: 500 }
      );
    }

    const prompt = `
Jesteś bardzo dobrym korepetytorem akademickim.

Odpowiadaj po polsku.
Wyjaśnij temat jasno, konkretnie i prostym językiem.
Struktura odpowiedzi:
1. Krótkie wyjaśnienie
2. Najważniejsze punkty
3. Prosty przykład
4. Na co uważać na egzaminie

PYTANIE:
${question}
`.trim();

    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        temperature: 0.4,
        messages: [
          {
            role: "user",
            content: prompt,
          },
        ],
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      return NextResponse.json(
        { error: `Błąd AI Tutor: ${response.status} ${errorText}` },
        { status: 500 }
      );
    }

    const data = await response.json();

    return NextResponse.json({
      answer:
        data.choices?.[0]?.message?.content?.trim() ??
        "AI nie zwróciło odpowiedzi.",
    });
  } catch (error) {
    console.error("AI tutor error:", error);

    return NextResponse.json({ error: "Błąd AI." }, { status: 500 });
  }
}
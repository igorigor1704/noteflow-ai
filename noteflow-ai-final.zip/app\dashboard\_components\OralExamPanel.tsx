"use client";

import { useMemo } from "react";

type OralExamPanelProps = {
  generatedQuestion?: string;
  question?: string;
  currentQuestion?: string;

  answer?: string;
  currentAnswer?: string;
  userAnswer?: string;

  score?: number;
  resultScore?: number;

  feedback?: string;
  verdict?: string;

  strengths?: string[];
  strongPoints?: string[];
  goodPoints?: string[];

  improvements?: string[];
  improvementPoints?: string[];
  toImprove?: string[];

  sampleAnswer?: string;
  modelAnswer?: string;
  betterAnswer?: string;

  loading?: boolean;
  generating?: boolean;
  evaluating?: boolean;

  onGenerateQuestion?: () => void;
  onGenerate?: () => void;

  onAnswerChange?: (value: string) => void;
  onChangeAnswer?: (value: string) => void;

  onEvaluateAnswer?: () => void;
  onEvaluate?: () => void;

  [key: string]: any;
};

function clampScore(value: number | undefined) {
  if (typeof value !== "number" || Number.isNaN(value)) {
    return 0;
  }

  return Math.max(0, Math.min(100, Math.round(value)));
}

function getScoreMeta(score: number) {
  if (score <= 10) {
    return {
      label: "Dopiero się rozkręcamy",
      description:
        "To jeszcze nie jest odpowiedź egzaminacyjna, ale przynajmniej system wie, od czego zacząć.",
      badgeClass: "bg-rose-100 text-rose-700",
      panelClass: "border-rose-200 bg-rose-50",
    };
  }

  if (score <= 35) {
    return {
      label: "Bardzo słabo",
      description:
        "Coś już drgnęło, ale odpowiedź wymaga solidnego uzupełnienia.",
      badgeClass: "bg-orange-100 text-orange-700",
      panelClass: "border-orange-200 bg-orange-50",
    };
  }

  if (score <= 60) {
    return {
      label: "Średnio",
      description:
        "Podstawy są, ale egzaminator jeszcze nie odłoży długopisu z uznaniem.",
      badgeClass: "bg-amber-100 text-amber-700",
      panelClass: "border-amber-200 bg-amber-50",
    };
  }

  if (score <= 80) {
    return {
      label: "Dobra odpowiedź",
      description:
        "Jest sens, jest struktura, jest wiedza. Warto dopracować szczegóły.",
      badgeClass: "bg-sky-100 text-sky-700",
      panelClass: "border-sky-200 bg-sky-50",
    };
  }

  return {
    label: "Bardzo dobra odpowiedź",
    description:
      "To już brzmi jak odpowiedź osoby, która wie, co mówi — miło widzieć.",
    badgeClass: "bg-emerald-100 text-emerald-700",
    panelClass: "border-emerald-200 bg-emerald-50",
  };
}

function buildStrengths(score: number, answer: string) {
  const trimmed = answer.trim();

  if (!trimmed) {
    return [
      "Odpowiedź jest bardzo krótka, więc przynajmniej nie próbujesz oszukiwać systemu.",
      "Brak lania wody — szkoda tylko, że brak też treści.",
    ];
  }

  if (score <= 10) {
    return [
      "Odpowiedź jest zwięzła i jednoznaczna.",
      "System wie już, że ten temat trzeba wrzucić wyżej w priorytetach.",
    ];
  }

  if (score <= 35) {
    return [
      "Widać próbę odniesienia się do pytania.",
      "Pojawiają się pojedyncze tropy związane z tematem.",
    ];
  }

  if (score <= 60) {
    return [
      "Odpowiedź pokazuje podstawowe zrozumienie zagadnienia.",
      "Poruszasz część ważnych elementów pytania.",
    ];
  }

  if (score <= 80) {
    return [
      "Odpowiedź jest logiczna i w większości trafna.",
      "Widać, że rozumiesz temat, a nie tylko go kojarzysz.",
    ];
  }

  return [
    "Odpowiedź jest merytoryczna i dobrze uporządkowana.",
    "Odnosisz się do kluczowych elementów pytania w sposób egzaminacyjny.",
  ];
}

function buildImprovements(score: number, question: string, answer: string) {
  const lowerQuestion = question.toLowerCase();
  const lowerAnswer = answer.toLowerCase();

  const items: string[] = [];

  if (!answer.trim()) {
    items.push("Napisz przynajmniej 3–4 pełne zdania zamiast zostawiać pustkę.");
    items.push("Zacznij od zdefiniowania głównych pojęć z pytania.");
    items.push("Potem wskaż różnice, zależności albo zastosowania — zależnie od treści pytania.");
    return items;
  }

  if (score <= 20) {
    items.push("Rozwiń odpowiedź — obecnie jest za krótka, żeby obronić ją na egzaminie.");
    items.push("Najpierw wyjaśnij podstawowe pojęcia pojawiające się w pytaniu.");
  }

  if (lowerQuestion.includes("różnic") || lowerQuestion.includes("róznic")) {
    items.push("Wyraźnie porównaj oba elementy pytania punkt po punkcie.");
  }

  if (
    lowerQuestion.includes("implikac") ||
    lowerQuestion.includes("zastosow") ||
    lowerQuestion.includes("wpływ")
  ) {
    items.push("Dodaj skutki praktyczne lub zastosowania — tego często brakuje w odpowiedziach.");
  }

  if (answer.trim().split(/\s+/).length < 25) {
    items.push("Dodaj więcej konkretów — obecnie odpowiedź jest zbyt skrótowa.");
  }

  if (score > 20 && score <= 60) {
    items.push("Uporządkuj odpowiedź: definicje → różnice → wniosek.");
  }

  if (score > 60) {
    items.push("Dla mocniejszego efektu dodaj przykład praktyczny albo jedno zdanie podsumowujące.");
  }

  return items.length > 0
    ? items
    : ["Doprecyzuj odpowiedź i dodaj jeden konkretny przykład."];
}

export default function OralExamPanel(props: OralExamPanelProps) {
  const {
    generatedQuestion,
    question,
    currentQuestion,

    answer,
    currentAnswer,
    userAnswer,

    score,
    resultScore,

    feedback,
    verdict,

    strengths,
    strongPoints,
    goodPoints,

    improvements,
    improvementPoints,
    toImprove,

    sampleAnswer,
    modelAnswer,
    betterAnswer,

    loading,
    generating,
    evaluating,

    onGenerateQuestion,
    onGenerate,

    onAnswerChange,
    onChangeAnswer,

    onEvaluateAnswer,
    onEvaluate,
  } = props;

  const resolvedQuestion =
    generatedQuestion || currentQuestion || question || "Kliknij, aby wygenerować pytanie egzaminacyjne.";

  const resolvedAnswer = answer ?? currentAnswer ?? userAnswer ?? "";
  const resolvedScore = clampScore(score ?? resultScore);

  const resolvedFeedback =
    feedback ||
    verdict ||
    getScoreMeta(resolvedScore).description;

  const resolvedStrengths =
    strengths ||
    strongPoints ||
    goodPoints ||
    buildStrengths(resolvedScore, resolvedAnswer);

  const resolvedImprovements =
    improvements ||
    improvementPoints ||
    toImprove ||
    buildImprovements(resolvedScore, resolvedQuestion, resolvedAnswer);

  const resolvedSampleAnswer =
    sampleAnswer || modelAnswer || betterAnswer || "";

  const handleGenerate = onGenerateQuestion || onGenerate;
  const handleEvaluate = onEvaluateAnswer || onEvaluate;
  const handleAnswerChange = onAnswerChange || onChangeAnswer;

  const scoreMeta = useMemo(() => getScoreMeta(resolvedScore), [resolvedScore]);

  return (
    <section className="grid gap-6 xl:grid-cols-[1.02fr_0.98fr]">
      <div className="rounded-[28px] border border-slate-200 bg-white p-6 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-violet-100 text-violet-700">
            <svg
              viewBox="0 0 24 24"
              className="h-5 w-5"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
            >
              <path d="M4 7l8-4 8 4-8 4-8-4Z" />
              <path d="M6 10v4c0 1.5 2.7 3 6 3s6-1.5 6-3v-4" />
            </svg>
          </div>

          <div>
            <p className="text-sm font-medium text-slate-500">Tryb ustny</p>
            <h2 className="text-2xl font-bold tracking-tight text-slate-900">
              Pytanie egzaminacyjne
            </h2>
          </div>
        </div>

        <div className="mt-5">
          <button
            type="button"
            onClick={handleGenerate}
            disabled={Boolean(loading || generating)}
            className="inline-flex items-center gap-2 rounded-2xl bg-violet-600 px-5 py-3 text-sm font-semibold text-white transition hover:bg-violet-700 disabled:opacity-60"
          >
            <svg
              viewBox="0 0 24 24"
              className="h-4 w-4"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
            >
              <path d="M12 18a4 4 0 0 0 4-4V8a4 4 0 1 0-8 0v6a4 4 0 0 0 4 4Z" />
              <path d="M19 10v4a7 7 0 0 1-14 0v-4" />
              <path d="M12 21v-3" />
            </svg>
            {loading || generating ? "Generowanie..." : "Wygeneruj pytanie"}
          </button>
        </div>

        <div className="mt-6 rounded-[24px] border border-slate-200 bg-slate-50 p-6">
          <p className="text-lg leading-9 text-slate-800">{resolvedQuestion}</p>
        </div>

        <div className="mt-6">
          <label className="mb-3 block text-xl font-semibold text-slate-900">
            Twoja odpowiedź
          </label>

          <textarea
            value={resolvedAnswer}
            onChange={(e) => handleAnswerChange?.(e.target.value)}
            rows={8}
            placeholder="Wpisz odpowiedź tak, jak mówiłabyś / mówiłbyś ją na egzaminie..."
            className="w-full rounded-[24px] border border-slate-300 px-5 py-4 text-base leading-8 text-slate-900 outline-none transition focus:border-violet-500"
          />

          <div className="mt-5">
            <button
              type="button"
              onClick={handleEvaluate}
              disabled={Boolean(loading || evaluating)}
              className="rounded-2xl bg-slate-900 px-5 py-3 text-sm font-semibold text-white transition hover:bg-slate-800 disabled:opacity-60"
            >
              {loading || evaluating ? "Ocenianie..." : "Oceń odpowiedź"}
            </button>
          </div>
        </div>
      </div>

      <div className="space-y-6">
        <section className="rounded-[28px] border border-slate-200 bg-white p-6 shadow-sm">
          <h3 className="text-2xl font-bold tracking-tight text-slate-900">
            Ocena odpowiedzi
          </h3>

          <div
            className={`mt-5 rounded-[24px] border p-6 ${scoreMeta.panelClass}`}
          >
            <p className="text-sm font-medium text-slate-500">Wynik</p>

            <div className="mt-2 flex flex-wrap items-end gap-4">
              <div className="text-6xl font-bold tracking-tight text-slate-950">
                {resolvedScore}
                <span className="text-3xl text-slate-500">/100</span>
              </div>

              <span
                className={`rounded-full px-3 py-1.5 text-sm font-semibold ${scoreMeta.badgeClass}`}
              >
                {scoreMeta.label}
              </span>
            </div>

            <p className="mt-4 text-base leading-8 text-slate-700">
              {resolvedFeedback}
            </p>
          </div>
        </section>

        <div className="grid gap-6 md:grid-cols-2">
          <section className="rounded-[28px] border border-slate-200 bg-white p-6 shadow-sm">
            <h4 className="text-2xl font-bold tracking-tight text-slate-900">
              Mocne strony
            </h4>

            {resolvedStrengths.length > 0 ? (
              <ul className="mt-5 space-y-4">
                {resolvedStrengths.map((item, index) => (
                  <li key={`${item}-${index}`} className="flex gap-3">
                    <span className="mt-1 inline-flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-emerald-100 text-xs font-bold text-emerald-700">
                      +
                    </span>
                    <span className="text-base leading-8 text-slate-700">
                      {item}
                    </span>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="mt-5 text-base leading-8 text-slate-600">
                Tu pojawią się najmocniejsze elementy odpowiedzi.
              </p>
            )}
          </section>

          <section className="rounded-[28px] border border-slate-200 bg-white p-6 shadow-sm">
            <h4 className="text-2xl font-bold tracking-tight text-slate-900">
              Co poprawić
            </h4>

            {resolvedImprovements.length > 0 ? (
              <ul className="mt-5 space-y-4">
                {resolvedImprovements.map((item, index) => (
                  <li key={`${item}-${index}`} className="flex gap-3">
                    <span className="mt-1 inline-flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-amber-100 text-xs font-bold text-amber-700">
                      !
                    </span>
                    <span className="text-base leading-8 text-slate-700">
                      {item}
                    </span>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="mt-5 text-base leading-8 text-slate-600">
                Tu pojawią się konkretne sugestie poprawy.
              </p>
            )}
          </section>
        </div>

        <section className="rounded-[28px] border border-slate-200 bg-white p-6 shadow-sm">
          <h4 className="text-2xl font-bold tracking-tight text-slate-900">
            Lepsza przykładowa odpowiedź
          </h4>

          <div className="mt-5 rounded-[24px] border border-slate-200 bg-slate-50 p-6">
            <p className="text-base leading-9 text-slate-700">
              {resolvedSampleAnswer ||
                "Po ocenie odpowiedzi tutaj pojawi się przykładowa, lepsza wersja odpowiedzi w stylu egzaminacyjnym."}
            </p>
          </div>
        </section>
      </div>
    </section>
  );
}
"use client";

import Link from "next/link";
import { Clock3, FileText, Sparkles, Target } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import HistoryPanel from "./_components/HistoryPanel";
import MaterialInputPanel from "./_components/MaterialInputPanel";
import OnboardingModal from "./_components/OnboardingModal";
import ResultTabsPanel from "./_components/ResultTabsPanel";
import SpacedRepetitionPanel from "./_components/SpacedRepetitionPanel";
import StudyGoalsCard from "./_components/StudyGoalsCard";
import { useDashboardState } from "./_hooks/useDashboardState";

export default function DashboardPage() {
  const dashboard = useDashboardState();
  const [mounted, setMounted] = useState(false);

  const resultRef = useRef<HTMLDivElement | null>(null);
  const historyRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    setMounted(true);
  }, []);

  const safeHistory = Array.isArray(dashboard.history) ? dashboard.history : [];
  const safeDueCards = Array.isArray(dashboard.dueCards) ? dashboard.dueCards : [];
  const safeFolders = Array.isArray(dashboard.folders) ? dashboard.folders : [];
  const safeAvailableTags = Array.isArray(dashboard.availableTags)
    ? dashboard.availableTags
    : [];
  const safeFilteredHistory = Array.isArray(dashboard.filteredHistory)
    ? dashboard.filteredHistory
    : [];

  const currentSpacedCard = dashboard.currentSpacedCard ?? null;

  const currentNotes = dashboard.currentAnalysis?.notes ?? {
    freeform: "",
    personalSummary: "",
    examFocus: "",
  };

  if (!mounted) {
    return (
      <main className="space-y-6">
        <div className="h-36 animate-pulse rounded-[28px] border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-900" />
        <div className="grid gap-6 xl:grid-cols-[1.15fr_0.85fr]">
          <div className="h-80 animate-pulse rounded-[28px] border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-900" />
          <div className="h-80 animate-pulse rounded-[28px] border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-900" />
        </div>
      </main>
    );
  }

  return (
    <>
      <OnboardingModal
        isOpen={!dashboard.preferences.onboardingCompleted}
        draft={dashboard.onboardingDraft}
        onChange={dashboard.updateOnboardingDraft}
        onSubmit={dashboard.completeOnboarding}
      />

      <main className="space-y-6">
        <section className="rounded-[28px] border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900">
          <div className="flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between">
            <div className="max-w-3xl">
              <div className="mb-3 flex flex-wrap items-center gap-2">
                <span className="rounded-full border border-indigo-200 bg-indigo-50 px-3 py-1 text-[11px] font-bold uppercase tracking-[0.18em] text-indigo-700 dark:border-indigo-500/20 dark:bg-indigo-500/10 dark:text-indigo-300">
                  Dashboard
                </span>
                <span className="rounded-full border border-slate-200 bg-white px-3 py-1 text-xs text-slate-500 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300">
                  Czytelniejszy układ
                </span>
              </div>

              <h1 className="text-3xl font-extrabold tracking-tight text-slate-950 dark:text-slate-100">
                Najpierw dodaj materiał, potem ucz się dalej
              </h1>

              <p className="mt-3 max-w-2xl text-sm leading-7 text-slate-600 dark:text-slate-300">
                Ten ekran ma być prosty. Najważniejszy krok to wrzucenie materiału,
                potem wynik analizy, a na końcu szybki powrót do historii i powtórek.
              </p>
            </div>

            <div className="flex flex-wrap gap-3">
              <button
                type="button"
                onClick={dashboard.analyzeText}
                className="rounded-2xl bg-slate-950 px-5 py-3 text-sm font-semibold text-white transition hover:opacity-90 dark:bg-white dark:text-slate-950"
              >
                Analizuj materiał
              </button>

              <button
                type="button"
                onClick={() =>
                  resultRef.current?.scrollIntoView({
                    behavior: "smooth",
                    block: "start",
                  })
                }
                className="rounded-2xl border border-slate-300 bg-white px-5 py-3 text-sm font-semibold text-slate-700 transition hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 dark:hover:bg-slate-800"
              >
                Przejdź do wyniku
              </button>

              <Link
                href="/dashboard/library"
                className="rounded-2xl border border-slate-300 bg-white px-5 py-3 text-sm font-semibold text-slate-700 transition hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 dark:hover:bg-slate-800"
              >
                Otwórz library
              </Link>
            </div>
          </div>
        </section>

        <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          <div className="rounded-[24px] border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-center justify-between gap-3">
              <p className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-500 dark:text-slate-400">
                Dzisiejsza nauka
              </p>
              <Clock3 className="h-5 w-5 text-slate-500" />
            </div>
            <p className="mt-4 text-3xl font-extrabold text-slate-950 dark:text-slate-100">
              {dashboard.stats.todayMinutes} min
            </p>
            <p className="mt-2 text-sm text-slate-600 dark:text-slate-300">
              Cel: {dashboard.preferences.dailyGoalMinutes} min
            </p>
          </div>

          <div className="rounded-[24px] border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-center justify-between gap-3">
              <p className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-500 dark:text-slate-400">
                Analizy
              </p>
              <FileText className="h-5 w-5 text-slate-500" />
            </div>
            <p className="mt-4 text-3xl font-extrabold text-slate-950 dark:text-slate-100">
              {safeHistory.length}
            </p>
            <p className="mt-2 text-sm text-slate-600 dark:text-slate-300">
              zapisanych materiałów
            </p>
          </div>

          <div className="rounded-[24px] border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-center justify-between gap-3">
              <p className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-500 dark:text-slate-400">
                Powtórki
              </p>
              <Target className="h-5 w-5 text-slate-500" />
            </div>
            <p className="mt-4 text-3xl font-extrabold text-slate-950 dark:text-slate-100">
              {safeDueCards.length}
            </p>
            <p className="mt-2 text-sm text-slate-600 dark:text-slate-300">
              fiszek czeka dziś
            </p>
          </div>

          <div className="rounded-[24px] border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-center justify-between gap-3">
              <p className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-500 dark:text-slate-400">
                Ready score
              </p>
              <Sparkles className="h-5 w-5 text-slate-500" />
            </div>
            <p className="mt-4 text-3xl font-extrabold text-slate-950 dark:text-slate-100">
              {dashboard.readyScore}%
            </p>
            <p className="mt-2 text-sm text-slate-600 dark:text-slate-300">
              gotowości do nauki
            </p>
          </div>
        </section>

        <div className="grid gap-6 xl:grid-cols-[1.15fr_0.85fr]">
          <div className="space-y-6">
            <section className="rounded-[28px] border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-800 dark:bg-slate-900">
              <MaterialInputPanel
                titleInput={dashboard.titleInput}
                tagsInput={dashboard.tagsInput}
                inputText={dashboard.inputText}
                loading={dashboard.loading}
                message={dashboard.message}
                folders={safeFolders}
                activeFolder={dashboard.activeFolder}
                newFolderName={dashboard.newFolderName}
                todayMinutes={dashboard.stats.todayMinutes}
                dailyGoalMinutes={dashboard.preferences.dailyGoalMinutes}
                onTitleChange={dashboard.setTitleInput}
                onTagsChange={dashboard.setTagsInput}
                onInputTextChange={dashboard.setInputText}
                onFolderSelect={dashboard.setActiveFolder}
                onNewFolderNameChange={dashboard.setNewFolderName}
                onCreateFolder={dashboard.createFolder}
                onFileSelected={dashboard.handleFileUpload}
                onAnalyze={dashboard.analyzeText}
                onClear={dashboard.clearAll}
                onExportTxt={dashboard.exportAnalysisToTXT}
                onExportCsv={dashboard.exportFlashcardsToCSV}
              />
            </section>

            <section
              ref={resultRef}
              className="rounded-[28px] border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-800 dark:bg-slate-900"
            >
              <div className="mb-4 flex items-center justify-between gap-3">
                <div>
                  <p className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-500 dark:text-slate-400">
                    Analysis result
                  </p>
                  <h3 className="mt-2 text-2xl font-bold tracking-tight text-slate-950 dark:text-slate-100">
                    Wynik analizy
                  </h3>
                </div>

                <button
                  type="button"
                  onClick={() =>
                    historyRef.current?.scrollIntoView({
                      behavior: "smooth",
                      block: "start",
                    })
                  }
                  className="rounded-2xl border border-slate-300 bg-white px-4 py-2.5 text-sm font-semibold text-slate-700 transition hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 dark:hover:bg-slate-800"
                >
                  Historia
                </button>
              </div>

              {dashboard.result ? (
                <ResultTabsPanel
                  result={dashboard.result}
                  activeTab={dashboard.activeTab}
                  flashcardIndex={dashboard.flashcardIndex}
                  selectedAnswers={dashboard.selectedAnswers}
                  showAnswers={dashboard.showAnswers}
                  quizScore={dashboard.quizScore}
                  answeredCount={dashboard.answeredCount}
                  currentNotes={currentNotes.freeform}
                  onTabChange={dashboard.setActiveTab}
                  onNotesChange={(value: string) =>
                    dashboard.updateAnalysisNotes({
                      freeform: value,
                      personalSummary: currentNotes.personalSummary,
                      examFocus: currentNotes.examFocus,
                    })
                  }
                  onPrevFlashcard={() => dashboard.changeFlashcard("prev")}
                  onNextFlashcard={() => dashboard.changeFlashcard("next")}
                  onSetSelectedAnswer={(questionIndex: number, value: string) =>
                    dashboard.setSelectedAnswers((prev: Record<number, string>) => ({
                      ...prev,
                      [questionIndex]: value,
                    }))
                  }
                  onToggleShowAnswers={() =>
                    dashboard.setShowAnswers((prev: boolean) => !prev)
                  }
                  onSubmitQuiz={dashboard.submitQuiz}
                  onResetQuiz={dashboard.resetQuiz}
                />
              ) : (
                <div className="rounded-[24px] border border-dashed border-slate-300 bg-slate-50 p-10 text-center dark:border-slate-700 dark:bg-slate-950">
                  <h4 className="text-lg font-semibold text-slate-900 dark:text-slate-100">
                    Tu pojawi się wynik analizy
                  </h4>
                  <p className="mt-2 text-sm leading-7 text-slate-600 dark:text-slate-300">
                    Dodaj tekst albo plik i kliknij analizę.
                  </p>
                </div>
              )}
            </section>

            <div ref={historyRef}>
              <HistoryPanel
                historySearch={dashboard.historySearch}
                onlyFavorites={dashboard.onlyFavorites}
                activeTag={dashboard.activeTag}
                availableTags={safeAvailableTags}
                filteredHistory={safeFilteredHistory}
                onHistorySearchChange={dashboard.setHistorySearch}
                onToggleOnlyFavorites={() =>
                  dashboard.setOnlyFavorites((prev: boolean) => !prev)
                }
                onSetActiveTag={dashboard.setActiveTag}
                onTogglePin={dashboard.togglePin}
                onToggleFavorite={dashboard.toggleFavorite}
                onOpen={dashboard.loadFromHistory}
                onRemove={dashboard.removeHistoryItem}
              />
            </div>
          </div>

          <div className="space-y-6">
            <StudyGoalsCard
              preferences={dashboard.preferences}
              todayMinutes={dashboard.stats.todayMinutes}
              currentStreak={dashboard.stats.streak}
              onUpdate={dashboard.updatePreferences}
            />

            <SpacedRepetitionPanel
              dueCards={safeDueCards}
              dueCardsCount={safeDueCards.length}
              spacedIndex={dashboard.spacedIndex}
              currentCard={currentSpacedCard}
              showSpacedBack={dashboard.showSpacedBack}
              showBack={dashboard.showSpacedBack}
              onPrev={() =>
                dashboard.setSpacedIndex((prev: number) =>
                  prev <= 0 ? Math.max(safeDueCards.length - 1, 0) : prev - 1
                )
              }
              onNext={() =>
                dashboard.setSpacedIndex((prev: number) =>
                  safeDueCards.length <= 1
                    ? 0
                    : prev >= safeDueCards.length - 1
                    ? 0
                    : prev + 1
                )
              }
              onToggleBack={() =>
                dashboard.setShowSpacedBack((prev: boolean) => !prev)
              }
              onReview={dashboard.reviewCurrentSpacedCard}
            />
          </div>
        </div>
      </main>
    </>
  );
}
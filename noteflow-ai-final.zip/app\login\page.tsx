"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "../lib/supabase/client";

export default function LoginPage() {
  const supabase = createClient();
  const router = useRouter();

  const [mode, setMode] = useState<"login" | "register">("login");
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLoading(true);
    setMessage("");

    try {
      if (mode === "register") {
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            data: {
              full_name: fullName.trim(),
            },
          },
        });

        if (error) {
          setMessage(error.message);
          return;
        }

        setMessage("Konto utworzone. Sprawdź maila i potwierdź rejestrację.");
        return;
      }

      const { error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) {
        setMessage(error.message);
        return;
      }

      router.push("/dashboard/profile");
      router.refresh();
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-slate-50 px-4">
      <div className="w-full max-w-md rounded-[28px] border border-slate-200 bg-white p-8 shadow-sm">
        <div className="mb-6">
          <p className="text-sm font-medium text-slate-500">Account</p>
          <h1 className="mt-1 text-3xl font-bold tracking-tight text-slate-900">
            {mode === "login" ? "Zaloguj się" : "Załóż konto"}
          </h1>
          <p className="mt-2 text-sm leading-6 text-slate-600">
            Zapisuj profil, postępy i ustawienia użytkownika na stałe.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {mode === "register" ? (
            <div>
              <label className="mb-2 block text-sm font-medium text-slate-700">
                Imię i nazwisko
              </label>
              <input
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                className="h-12 w-full rounded-2xl border border-slate-300 px-4 outline-none transition focus:border-slate-500"
                placeholder="Np. Maja Kowalska"
              />
            </div>
          ) : null}

          <div>
            <label className="mb-2 block text-sm font-medium text-slate-700">
              Email
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="h-12 w-full rounded-2xl border border-slate-300 px-4 outline-none transition focus:border-slate-500"
              placeholder="twoj@email.com"
              required
            />
          </div>

          <div>
            <label className="mb-2 block text-sm font-medium text-slate-700">
              Hasło
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="h-12 w-full rounded-2xl border border-slate-300 px-4 outline-none transition focus:border-slate-500"
              placeholder="Minimum 6 znaków"
              required
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="flex h-12 w-full items-center justify-center rounded-2xl bg-slate-900 px-4 font-semibold text-white transition hover:bg-slate-800 disabled:opacity-60"
          >
            {loading
              ? "Trwa..."
              : mode === "login"
              ? "Zaloguj się"
              : "Utwórz konto"}
          </button>
        </form>

        {message ? (
          <p className="mt-4 text-sm leading-6 text-slate-600">{message}</p>
        ) : null}

        <button
          type="button"
          onClick={() =>
            setMode((prev) => (prev === "login" ? "register" : "login"))
          }
          className="mt-6 text-sm font-medium text-slate-700 underline"
        >
          {mode === "login"
            ? "Nie masz konta? Zarejestruj się"
            : "Masz konto? Zaloguj się"}
        </button>
      </div>
    </main>
  );
}
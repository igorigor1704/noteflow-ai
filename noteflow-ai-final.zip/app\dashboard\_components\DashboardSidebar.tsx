"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Bell,
  BookOpen,
  Flame,
  LayoutGrid,
  Library,
  Medal,
  Sparkles,
  TimerReset,
  Zap,
} from "lucide-react";

type ActivityDay =
  | string
  | {
      date: string;
      count: number;
    };

type DashboardSidebarProps = {
  focusSeconds?: number;
  focusRunning?: boolean;
  reminderMinutes?: string;
  progressToNextLevel?: number;
  achievementBadges?: string[];
  activityDays?: ActivityDay[];
  onToggleFocus?: () => void;
  onResetFocus?: () => void;
  onReminderMinutesChange?: (value: string) => void;
  onEnableNotifications?: () => void;
  onScheduleReminder?: () => void;
};

function formatTimer(totalSeconds: number) {
  const safe = Number.isFinite(totalSeconds) ? Math.max(0, totalSeconds) : 0;
  const minutes = Math.floor(safe / 60);
  const seconds = safe % 60;

  return `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
}

function getActivityTone(count: number) {
  if (count >= 4) return "bg-slate-950 dark:bg-white";
  if (count === 3) return "bg-slate-700 dark:bg-slate-300";
  if (count === 2) return "bg-slate-500 dark:bg-slate-500";
  if (count === 1) return "bg-slate-300 dark:bg-slate-700";
  return "bg-slate-100 dark:bg-slate-800";
}

const navItems = [
  {
    href: "/dashboard",
    label: "Dashboard",
    description: "Główny widok nauki",
    icon: LayoutGrid,
  },
  {
    href: "/dashboard/today",
    label: "Today",
    description: "Pytania, fiszki i plan dnia",
    icon: BookOpen,
  },
  {
    href: "/dashboard/library",
    label: "Library",
    description: "Wszystkie analizy i materiały",
    icon: Library,
  },
  {
    href: "/pricing",
    label: "Pricing",
    description: "Plan FREE i PRO",
    icon: Sparkles,
  },
];

export default function DashboardSidebar({
  focusSeconds = 0,
  focusRunning = false,
  reminderMinutes = "25",
  progressToNextLevel = 0,
  achievementBadges = [],
  activityDays = [],
  onToggleFocus = () => {},
  onResetFocus = () => {},
  onReminderMinutesChange = () => {},
  onEnableNotifications = () => {},
  onScheduleReminder = () => {},
}: DashboardSidebarProps) {
  const pathname = usePathname();

  const normalizedDays = (Array.isArray(activityDays) ? activityDays : []).map((day) =>
    typeof day === "string" ? { date: day, count: 0 } : day
  );

  const progressPercent = Math.max(
    0,
    Math.min(100, Math.round((progressToNextLevel || 0) * 100))
  );

  const safeBadges = Array.isArray(achievementBadges) ? achievementBadges : [];

  return (
    <aside className="space-y-5">
      <section className="rounded-[28px] border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-800 dark:bg-slate-900">
        <div className="mb-4 px-2">
          <p className="text-[11px] font-bold uppercase tracking-[0.22em] text-slate-500 dark:text-slate-400">
            NoteFlow AI
          </p>
          <h2 className="mt-2 text-xl font-bold text-slate-950 dark:text-slate-100">
            Study workspace
          </h2>
        </div>

        <nav className="space-y-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive =
              pathname === item.href ||
              (item.href !== "/dashboard" && pathname?.startsWith(item.href));

            return (
              <Link
                key={item.href}
                href={item.href}
                className={`flex items-start gap-3 rounded-[20px] border px-4 py-3 transition ${
                  isActive
                    ? "border-slate-950 bg-slate-950 text-white shadow-[0_16px_36px_rgba(15,23,42,0.18)] dark:border-white dark:bg-white dark:text-slate-950"
                    : "border-slate-200 bg-white text-slate-700 hover:-translate-y-0.5 hover:border-slate-300 hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-200 dark:hover:border-slate-700 dark:hover:bg-slate-800"
                }`}
              >
                <div
                  className={`mt-0.5 rounded-xl p-2 ${
                    isActive
                      ? "bg-white/15 dark:bg-slate-200"
                      : "bg-slate-100 dark:bg-slate-800"
                  }`}
                >
                  <Icon className="h-4 w-4" />
                </div>

                <div className="min-w-0">
                  <p className="text-sm font-semibold">{item.label}</p>
                  <p
                    className={`mt-1 text-xs leading-5 ${
                      isActive
                        ? "text-white/80 dark:text-slate-700"
                        : "text-slate-500 dark:text-slate-400"
                    }`}
                  >
                    {item.description}
                  </p>
                </div>
              </Link>
            );
          })}
        </nav>
      </section>

      <section className="rounded-[28px] border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
        <div className="mb-5 flex items-start justify-between gap-3">
          <div>
            <p className="text-[11px] font-bold uppercase tracking-[0.22em] text-slate-500 dark:text-slate-400">
              Focus mode
            </p>
            <h2 className="mt-2 text-xl font-bold text-slate-950 dark:text-slate-100">
              Skupienie i przypomnienia
            </h2>
          </div>
          <span className="inline-flex items-center gap-2 rounded-full border border-slate-200 px-3 py-1.5 text-xs font-semibold text-slate-600 dark:border-slate-700 dark:text-slate-300">
            <Zap className="h-3.5 w-3.5" />
            Study
          </span>
        </div>

        <div className="rounded-[24px] border border-slate-200 bg-slate-50 p-5 dark:border-slate-800 dark:bg-slate-950">
          <p className="text-sm text-slate-500 dark:text-slate-400">Focus timer</p>
          <div className="mt-3 flex items-end justify-between gap-3">
            <p className="text-5xl font-black tracking-tight text-slate-950 dark:text-slate-100">
              {formatTimer(focusSeconds)}
            </p>
            <span className="rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-[11px] font-bold uppercase tracking-[0.18em] text-emerald-700 dark:border-emerald-500/20 dark:bg-emerald-500/10 dark:text-emerald-300">
              {focusRunning ? "Running" : "Paused"}
            </span>
          </div>

          <div className="mt-5 flex flex-wrap gap-3">
            <button
              type="button"
              onClick={onToggleFocus}
              className="rounded-2xl bg-slate-950 px-4 py-2.5 text-sm font-semibold text-white transition hover:opacity-90 dark:bg-white dark:text-slate-950"
            >
              {focusRunning ? "Pauza" : "Start focus"}
            </button>

            <button
              type="button"
              onClick={onResetFocus}
              className="inline-flex items-center gap-2 rounded-2xl border border-slate-300 bg-white px-4 py-2.5 text-sm font-semibold text-slate-700 transition hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 dark:hover:bg-slate-800"
            >
              <TimerReset className="h-4 w-4" />
              Reset
            </button>
          </div>
        </div>

        <div className="mt-5 space-y-3">
          <label className="block text-sm font-semibold text-slate-700 dark:text-slate-200">
            Przypomnienie za ile minut
          </label>

          <input
            type="number"
            min="1"
            value={reminderMinutes}
            onChange={(e) => onReminderMinutesChange(e.target.value)}
            className="w-full rounded-2xl border border-slate-300 bg-white px-4 py-3 text-sm text-slate-900 outline-none transition focus:border-slate-400 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            placeholder="Np. 25"
          />

          <div className="flex flex-wrap gap-3">
            <button
              type="button"
              onClick={onEnableNotifications}
              className="inline-flex items-center gap-2 rounded-2xl border border-slate-300 bg-white px-4 py-2.5 text-sm font-semibold text-slate-700 transition hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 dark:hover:bg-slate-800"
            >
              <Bell className="h-4 w-4" />
              Powiadomienia
            </button>

            <button
              type="button"
              onClick={onScheduleReminder}
              className="rounded-2xl border border-slate-300 bg-white px-4 py-2.5 text-sm font-semibold text-slate-700 transition hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 dark:hover:bg-slate-800"
            >
              Ustaw reminder
            </button>
          </div>
        </div>
      </section>

      <section className="rounded-[28px] border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
        <div className="mb-5 flex items-start justify-between gap-3">
          <div>
            <p className="text-[11px] font-bold uppercase tracking-[0.22em] text-slate-500 dark:text-slate-400">
              Progress
            </p>
            <h2 className="mt-2 text-xl font-bold text-slate-950 dark:text-slate-100">
              Poziom i aktywność
            </h2>
          </div>

          <span className="inline-flex items-center gap-2 rounded-full border border-slate-200 px-3 py-1.5 text-xs font-semibold text-slate-600 dark:border-slate-700 dark:text-slate-300">
            <Flame className="h-3.5 w-3.5" />
            Momentum
          </span>
        </div>

        <div className="rounded-[22px] border border-slate-200 bg-slate-50 p-4 dark:border-slate-800 dark:bg-slate-950">
          <div className="mb-2 flex items-center justify-between text-sm text-slate-500 dark:text-slate-400">
            <span>Progress do kolejnego levelu</span>
            <span className="font-semibold text-slate-700 dark:text-slate-200">
              {progressPercent}%
            </span>
          </div>

          <div className="h-2.5 rounded-full bg-slate-200 dark:bg-slate-800">
            <div
              className="h-2.5 rounded-full bg-slate-950 transition-all dark:bg-white"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>

        <div className="mt-5">
          <div className="mb-3 flex items-center gap-2">
            <Medal className="h-4 w-4 text-slate-500" />
            <p className="text-sm font-semibold text-slate-700 dark:text-slate-200">
              Osiągnięcia
            </p>
          </div>

          <div className="flex flex-wrap gap-2">
            {safeBadges.length > 0 ? (
              safeBadges.map((badge) => (
                <span
                  key={badge}
                  className="inline-flex items-center rounded-full border border-slate-200 px-3 py-1.5 text-xs font-semibold text-slate-700 dark:border-slate-700 dark:text-slate-200"
                >
                  {badge}
                </span>
              ))
            ) : (
              <p className="text-sm text-slate-500 dark:text-slate-400">
                Brak osiągnięć jeszcze.
              </p>
            )}
          </div>
        </div>

        <div className="mt-6">
          <p className="mb-3 text-sm font-semibold text-slate-700 dark:text-slate-200">
            Aktywność 14 dni
          </p>

          <div className="grid grid-cols-7 gap-2">
            {normalizedDays.length > 0 ? (
              normalizedDays.map((day) => (
                <div
                  key={day.date}
                  title={`${day.date}: ${day.count}`}
                  className={`aspect-square rounded-xl border border-white/40 ${getActivityTone(
                    day.count
                  )}`}
                />
              ))
            ) : (
              Array.from({ length: 14 }).map((_, index) => (
                <div
                  key={index}
                  className="aspect-square rounded-xl bg-slate-100 dark:bg-slate-800"
                />
              ))
            )}
          </div>
        </div>
      </section>
    </aside>
  );
}
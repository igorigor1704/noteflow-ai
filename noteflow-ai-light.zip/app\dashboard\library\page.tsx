"use client";

import Link from "next/link";
import { FolderOpen, Library, Pin, Search, Star } from "lucide-react";
import { useMemo, useState } from "react";
import { useStudyStore } from "../../store/useStudyStore";
import LibraryAnalysisCard from "../_components/LibraryAnalysisCard";
import {
  DEFAULT_FOLDERS,
  extractAllTags,
  matchesFolder,
  matchesSearch,
  matchesTag,
  sortAnalyses,
  type LibraryAnalysis,
  type LibrarySortOption,
} from "../_lib/library";

function toSafeText(value: unknown): string {
  if (typeof value === "string") return value;
  if (typeof value === "number") return String(value);
  return "";
}

function toSafeStringArray(value: unknown): string[] {
  if (!Array.isArray(value)) return [];

  return value
    .map((item) => {
      if (typeof item === "string") return item;
      if (typeof item === "number") return String(item);

      if (item && typeof item === "object") {
        const candidate = item as {
          term?: unknown;
          front?: unknown;
          label?: unknown;
          name?: unknown;
          title?: unknown;
        };

        if (typeof candidate.term === "string") return candidate.term;
        if (typeof candidate.front === "string") return candidate.front;
        if (typeof candidate.label === "string") return candidate.label;
        if (typeof candidate.name === "string") return candidate.name;
        if (typeof candidate.title === "string") return candidate.title;
      }

      return "";
    })
    .filter((item) => item.trim().length > 0);
}

function getFolderId(folder: unknown, index: number): string {
  if (folder && typeof folder === "object") {
    const candidate = folder as { id?: unknown };
    if (typeof candidate.id === "string" && candidate.id.trim()) {
      return candidate.id;
    }
  }

  return `folder-${index}`;
}

function getFolderLabel(folder: unknown, index: number): string {
  if (folder && typeof folder === "object") {
    const candidate = folder as {
      label?: unknown;
      name?: unknown;
      title?: unknown;
    };

    if (typeof candidate.label === "string" && candidate.label.trim()) {
      return candidate.label;
    }

    if (typeof candidate.name === "string" && candidate.name.trim()) {
      return candidate.name;
    }

    if (typeof candidate.title === "string" && candidate.title.trim()) {
      return candidate.title;
    }
  }

  return index === 0 ? "Wszystkie foldery" : "Folder";
}

const sortOptions: { value: LibrarySortOption; label: string }[] = [
  { value: "newest", label: "Najnowsze" },
  { value: "oldest", label: "Najstarsze" },
  { value: "title-asc", label: "Tytuł A–Z" },
  { value: "title-desc", label: "Tytuł Z–A" },
];

export default function LibraryPage() {
  const analyses = useStudyStore((state) => state.analyses);
  const togglePin = useStudyStore((state) => state.togglePin);
  const toggleFavorite = useStudyStore((state) => state.toggleFavorite);

  const [search, setSearch] = useState("");
  const [sortBy, setSortBy] = useState<LibrarySortOption>("newest");
  const [activeFolderId, setActiveFolderId] = useState("all");
  const [activeTag, setActiveTag] = useState("all");

  const folderOptions = useMemo(
    () =>
      (Array.isArray(DEFAULT_FOLDERS) ? DEFAULT_FOLDERS : []).map((folder, index) => ({
        id: getFolderId(folder, index),
        label: getFolderLabel(folder, index),
      })),
    []
  );

  const normalizedAnalyses = useMemo<LibraryAnalysis[]>(
    () =>
      (Array.isArray(analyses) ? analyses : []).map((item) => ({
        id: toSafeText(item?.id) || crypto.randomUUID(),
        title: toSafeText(item?.title)?.trim() || "Bez tytułu",
        createdAt: toSafeText(item?.createdAt) || new Date().toISOString(),
        summary: toSafeText(item?.summary),
        keywords: toSafeStringArray(item?.concepts),
        tags: toSafeStringArray(item?.tags),
        folderId:
          typeof item?.folder === "string" && item.folder.trim().length > 0
            ? item.folder
            : null,
        isPinned: Boolean(item?.pinned),
        isFavorite: Boolean(item?.favorite),
      })),
    [analyses]
  );

  const allTags = useMemo(() => extractAllTags(normalizedAnalyses), [normalizedAnalyses]);

  const visibleAnalyses = useMemo(() => {
    const filtered = normalizedAnalyses.filter(
      (item) =>
        matchesSearch(item, search) &&
        matchesFolder(item, activeFolderId) &&
        matchesTag(item, activeTag)
    );

    return sortAnalyses(filtered, sortBy);
  }, [normalizedAnalyses, search, activeFolderId, activeTag, sortBy]);

  const stats = useMemo(() => {
    const pinned = normalizedAnalyses.filter((item) => item.isPinned).length;
    const favorites = normalizedAnalyses.filter((item) => item.isFavorite).length;

    return {
      total: normalizedAnalyses.length,
      visible: visibleAnalyses.length,
      pinned,
      favorites,
      tags: allTags.length,
    };
  }, [normalizedAnalyses, visibleAnalyses, allTags]);

  return (
    <main className="space-y-6">
      <section className="rounded-[28px] border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900">
        <div className="flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between">
          <div className="max-w-3xl">
            <div className="mb-3 flex flex-wrap items-center gap-2">
              <span className="rounded-full border border-indigo-200 bg-indigo-50 px-3 py-1 text-[11px] font-bold uppercase tracking-[0.18em] text-indigo-700 dark:border-indigo-500/20 dark:bg-indigo-500/10 dark:text-indigo-300">
                Library
              </span>
              <span className="rounded-full border border-slate-200 bg-white px-3 py-1 text-xs text-slate-500 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300">
                Uporządkowane analizy
              </span>
            </div>

            <h2 className="text-3xl font-extrabold tracking-tight text-slate-950 dark:text-slate-100">
              Twoja biblioteka materiałów
            </h2>

            <p className="mt-3 max-w-2xl text-sm leading-7 text-slate-600 dark:text-slate-300">
              Szybko znajduj analizy, przypinaj ważne materiały i wracaj do nauki
              bez chaosu.
            </p>
          </div>

          <div className="flex flex-wrap gap-3">
            <Link
              href="/dashboard"
              className="rounded-2xl border border-slate-300 bg-white px-5 py-3 text-sm font-semibold text-slate-700 transition hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 dark:hover:bg-slate-800"
            >
              Wróć do dashboardu
            </Link>

            <Link
              href="/pricing"
              className="rounded-2xl bg-slate-950 px-5 py-3 text-sm font-semibold text-white transition hover:opacity-90 dark:bg-white dark:text-slate-950"
            >
              Zobacz pricing
            </Link>
          </div>
        </div>
      </section>

      <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <div className="rounded-[24px] border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between gap-3">
            <p className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-500 dark:text-slate-400">
              Wszystkie
            </p>
            <Library className="h-5 w-5 text-slate-500" />
          </div>
          <p className="mt-4 text-3xl font-extrabold text-slate-950 dark:text-slate-100">
            {stats.total}
          </p>
          <p className="mt-2 text-sm text-slate-600 dark:text-slate-300">
            zapisanych analiz
          </p>
        </div>

        <div className="rounded-[24px] border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between gap-3">
            <p className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-500 dark:text-slate-400">
              Widoczne
            </p>
            <Search className="h-5 w-5 text-slate-500" />
          </div>
          <p className="mt-4 text-3xl font-extrabold text-slate-950 dark:text-slate-100">
            {stats.visible}
          </p>
          <p className="mt-2 text-sm text-slate-600 dark:text-slate-300">
            po filtrach
          </p>
        </div>

        <div className="rounded-[24px] border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between gap-3">
            <p className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-500 dark:text-slate-400">
              Przypięte
            </p>
            <Pin className="h-5 w-5 text-slate-500" />
          </div>
          <p className="mt-4 text-3xl font-extrabold text-slate-950 dark:text-slate-100">
            {stats.pinned}
          </p>
          <p className="mt-2 text-sm text-slate-600 dark:text-slate-300">
            ważnych materiałów
          </p>
        </div>

        <div className="rounded-[24px] border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between gap-3">
            <p className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-500 dark:text-slate-400">
              Ulubione
            </p>
            <Star className="h-5 w-5 text-slate-500" />
          </div>
          <p className="mt-4 text-3xl font-extrabold text-slate-950 dark:text-slate-100">
            {stats.favorites}
          </p>
          <p className="mt-2 text-sm text-slate-600 dark:text-slate-300">
            oznaczonych analiz
          </p>
        </div>
      </section>

      <section className="rounded-[28px] border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900">
        <div className="grid gap-4 xl:grid-cols-[1.2fr_0.8fr]">
          <div className="relative">
            <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Szukaj po tytule, streszczeniu lub tagach..."
              className="w-full rounded-2xl border border-slate-300 bg-white py-3 pl-11 pr-4 text-sm text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-slate-400 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100 dark:placeholder:text-slate-500"
            />
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as LibrarySortOption)}
              className="w-full rounded-2xl border border-slate-300 bg-white px-4 py-3 text-sm font-medium text-slate-700 outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            >
              {sortOptions.map((option) => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>

            <div className="flex items-center gap-3 rounded-2xl border border-slate-300 bg-white px-4 py-3 dark:border-slate-700 dark:bg-slate-950">
              <FolderOpen className="h-4 w-4 text-slate-500" />
              <select
                value={activeFolderId}
                onChange={(e) => setActiveFolderId(e.target.value)}
                className="w-full bg-transparent text-sm font-medium text-slate-700 outline-none dark:text-slate-100"
              >
                {folderOptions.map((folder) => (
                  <option key={folder.id} value={folder.id}>
                    {folder.label}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {allTags.length > 0 ? (
          <div className="mt-5 flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => setActiveTag("all")}
              className={`rounded-full px-3 py-1.5 text-xs font-semibold transition ${
                activeTag === "all"
                  ? "bg-slate-950 text-white dark:bg-white dark:text-slate-950"
                  : "border border-slate-300 bg-white text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200 dark:hover:bg-slate-800"
              }`}
            >
              Wszystkie tagi
            </button>

            {allTags.map((tag) => (
              <button
                key={tag}
                type="button"
                onClick={() => setActiveTag(tag)}
                className={`rounded-full px-3 py-1.5 text-xs font-semibold transition ${
                  activeTag === tag
                    ? "bg-slate-950 text-white dark:bg-white dark:text-slate-950"
                    : "border border-slate-300 bg-white text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200 dark:hover:bg-slate-800"
                }`}
              >
                #{tag}
              </button>
            ))}
          </div>
        ) : null}
      </section>

      <section className="rounded-[28px] border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900">
        {visibleAnalyses.length === 0 ? (
          <div className="rounded-[24px] border border-dashed border-slate-300 bg-slate-50 p-10 text-center dark:border-slate-700 dark:bg-slate-950">
            <h3 className="text-lg font-semibold text-slate-900 dark:text-slate-100">
              Nic tu jeszcze nie ma
            </h3>
            <p className="mt-2 text-sm leading-7 text-slate-600 dark:text-slate-300">
              Dodaj pierwszą analizę albo wyczyść filtry.
            </p>

            <div className="mt-6 flex flex-wrap justify-center gap-3">
              <Link
                href="/dashboard"
                className="rounded-2xl bg-slate-950 px-5 py-3 text-sm font-semibold text-white transition hover:opacity-90 dark:bg-white dark:text-slate-950"
              >
                Dodaj analizę
              </Link>

              <button
                type="button"
                onClick={() => {
                  setSearch("");
                  setSortBy("newest");
                  setActiveFolderId("all");
                  setActiveTag("all");
                }}
                className="rounded-2xl border border-slate-300 bg-white px-5 py-3 text-sm font-semibold text-slate-700 transition hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 dark:hover:bg-slate-800"
              >
                Wyczyść filtry
              </button>
            </div>
          </div>
        ) : (
          <>
            <div className="mb-5 flex flex-wrap items-center justify-between gap-3 rounded-[20px] border border-slate-200 bg-slate-50 px-4 py-3 text-sm dark:border-slate-800 dark:bg-slate-950">
              <span className="text-slate-600 dark:text-slate-300">
                Pokazuję <strong>{visibleAnalyses.length}</strong>{" "}
                {visibleAnalyses.length === 1 ? "analizę" : "analiz"}
              </span>
              <span className="text-slate-500 dark:text-slate-400">
                Tagi: {stats.tags}
              </span>
            </div>

            <div className="grid gap-4 lg:grid-cols-2">
              {visibleAnalyses.map((analysis) => (
                <LibraryAnalysisCard
                  key={analysis.id}
                  analysis={analysis}
                  onTogglePinned={() => togglePin(analysis.id)}
                  onToggleFavorite={() => toggleFavorite(analysis.id)}
                />
              ))}
            </div>
          </>
        )}
      </section>
    </main>
  );
}
"use client";

import {
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  HelpCircle,
  Layers3,
  ListTodo,
  NotebookPen,
  ScrollText,
} from "lucide-react";
import { type AnalysisResult, type TabName, tabs } from "../_lib/types";

type Props = {
  result: AnalysisResult;
  activeTab: TabName;
  flashcardIndex: number;
  selectedAnswers: Record<number, string>;
  showAnswers: boolean;
  quizScore: number;
  answeredCount: number;
  currentNotes: string;
  onTabChange: (tab: TabName) => void;
  onNotesChange: (value: string) => void;
  onPrevFlashcard: () => void;
  onNextFlashcard: () => void;
  onSetSelectedAnswer: (questionIndex: number, value: string) => void;
  onToggleShowAnswers: () => void;
  onSubmitQuiz: () => void;
  onResetQuiz: () => void;
};

function normalizeTab(value: unknown) {
  return String(value).trim().toLowerCase();
}

function isTab(activeTab: unknown, aliases: string[]) {
  const normalized = normalizeTab(activeTab);
  return aliases.some((alias) => normalized === alias);
}

function getTabIcon(tab: unknown) {
  const value = normalizeTab(tab);

  if (value === "summary" || value === "streszczenie") {
    return <ScrollText className="h-4 w-4" />;
  }

  if (value === "concepts" || value === "pojęcia" || value === "pojecia") {
    return <Layers3 className="h-4 w-4" />;
  }

  if (value === "questions" || value === "pytania") {
    return <HelpCircle className="h-4 w-4" />;
  }

  if (value === "flashcards" || value === "fiszki") {
    return <NotebookPen className="h-4 w-4" />;
  }

  if (value === "quiz") {
    return <CheckCircle2 className="h-4 w-4" />;
  }

  if (value === "studyplan" || value === "plan nauki") {
    return <ListTodo className="h-4 w-4" />;
  }

  return <ScrollText className="h-4 w-4" />;
}

export default function ResultTabsPanel({
  result,
  activeTab,
  flashcardIndex,
  selectedAnswers,
  showAnswers,
  quizScore,
  answeredCount,
  currentNotes,
  onTabChange,
  onNotesChange,
  onPrevFlashcard,
  onNextFlashcard,
  onSetSelectedAnswer,
  onToggleShowAnswers,
  onSubmitQuiz,
  onResetQuiz,
}: Props) {
  const flashcards = Array.isArray(result.flashcards) ? result.flashcards : [];
  const quiz = Array.isArray(result.quiz) ? result.quiz : [];
  const concepts = Array.isArray(result.concepts) ? result.concepts : [];
  const questions = Array.isArray(result.questions) ? result.questions : [];
  const studyPlan = Array.isArray(result.studyPlan) ? result.studyPlan : [];

  const currentFlashcard =
    flashcards.length > 0 ? flashcards[Math.min(flashcardIndex, flashcards.length - 1)] : null;

  const showSummary = isTab(activeTab, ["summary", "streszczenie"]);
  const showConcepts = isTab(activeTab, ["concepts", "pojęcia", "pojecia"]);
  const showQuestions = isTab(activeTab, ["questions", "pytania"]);
  const showFlashcards = isTab(activeTab, ["flashcards", "fiszki"]);
  const showQuiz = isTab(activeTab, ["quiz"]);
  const showStudyPlan = isTab(activeTab, ["studyplan", "plan nauki"]);

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap gap-2">
        {tabs.map((tab) => {
          const active = String(activeTab) === String(tab);

          return (
            <button
              key={String(tab)}
              type="button"
              onClick={() => onTabChange(tab)}
              className={`inline-flex items-center gap-2 rounded-2xl px-4 py-2.5 text-sm font-semibold transition ${
                active
                  ? "bg-slate-950 text-white dark:bg-white dark:text-slate-950"
                  : "border border-slate-300 bg-white text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100 dark:hover:bg-slate-800"
              }`}
            >
              {getTabIcon(tab)}
              {String(tab)}
            </button>
          );
        })}
      </div>

      {showSummary ? (
        <section className="space-y-4">
          <div className="rounded-[24px] border border-slate-200 bg-slate-50 p-5 dark:border-slate-800 dark:bg-slate-950">
            <h4 className="text-lg font-bold text-slate-950 dark:text-slate-100">
              Streszczenie
            </h4>
            <p className="mt-3 whitespace-pre-wrap text-sm leading-8 text-slate-700 dark:text-slate-300">
              {result.summary || "Brak podsumowania."}
            </p>
          </div>

          <div className="rounded-[24px] border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-950">
            <label className="mb-2 block text-sm font-semibold text-slate-700 dark:text-slate-200">
              Twoje notatki
            </label>
            <textarea
              value={currentNotes}
              onChange={(e) => onNotesChange(e.target.value)}
              placeholder="Dopisuj własne notatki, skróty i najważniejsze rzeczy do zapamiętania..."
              className="min-h-[180px] w-full resize-none rounded-[22px] border border-slate-300 bg-white px-4 py-4 text-sm leading-7 text-slate-900 outline-none transition focus:border-slate-400 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
            />
          </div>
        </section>
      ) : null}

      {showConcepts ? (
        <section className="grid gap-4 md:grid-cols-2">
          {concepts.length > 0 ? (
            concepts.map((concept, index) => (
              <div
                key={`${String(concept)}-${index}`}
                className="rounded-[24px] border border-slate-200 bg-slate-50 p-5 dark:border-slate-800 dark:bg-slate-950"
              >
                <p className="text-sm leading-7 text-slate-700 dark:text-slate-300">
                  {typeof concept === "string" ? concept : JSON.stringify(concept)}
                </p>
              </div>
            ))
          ) : (
            <div className="rounded-[24px] border border-dashed border-slate-300 bg-slate-50 p-10 text-center dark:border-slate-700 dark:bg-slate-950">
              <p className="text-sm text-slate-600 dark:text-slate-300">Brak pojęć.</p>
            </div>
          )}
        </section>
      ) : null}

      {showQuestions ? (
        <section className="space-y-4">
          {questions.length > 0 ? (
            questions.map((question, index) => (
              <div
                key={`${String(question)}-${index}`}
                className="rounded-[24px] border border-slate-200 bg-slate-50 p-5 dark:border-slate-800 dark:bg-slate-950"
              >
                <p className="text-sm font-semibold uppercase tracking-[0.18em] text-slate-500 dark:text-slate-400">
                  Pytanie {index + 1}
                </p>
                <p className="mt-3 text-sm leading-8 text-slate-700 dark:text-slate-300">
                  {typeof question === "string" ? question : JSON.stringify(question)}
                </p>
              </div>
            ))
          ) : (
            <div className="rounded-[24px] border border-dashed border-slate-300 bg-slate-50 p-10 text-center dark:border-slate-700 dark:bg-slate-950">
              <p className="text-sm text-slate-600 dark:text-slate-300">Brak pytań.</p>
            </div>
          )}
        </section>
      ) : null}

      {showFlashcards ? (
        <section className="space-y-4">
          {currentFlashcard ? (
            <>
              <div className="rounded-[28px] border border-slate-200 bg-slate-50 p-6 dark:border-slate-800 dark:bg-slate-950">
                <p className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-500 dark:text-slate-400">
                  Fiszka {Math.min(flashcardIndex + 1, flashcards.length)} / {flashcards.length}
                </p>

                <div className="mt-5 grid gap-4 md:grid-cols-2">
                  <div className="rounded-[24px] border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
                    <p className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-500 dark:text-slate-400">
                      Przód
                    </p>
                    <p className="mt-3 text-sm leading-8 text-slate-700 dark:text-slate-300">
                      {typeof currentFlashcard === "object" && currentFlashcard
                        ? "front" in currentFlashcard
                          ? String(currentFlashcard.front)
                          : JSON.stringify(currentFlashcard)
                        : String(currentFlashcard)}
                    </p>
                  </div>

                  <div className="rounded-[24px] border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
                    <p className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-500 dark:text-slate-400">
                      Tył
                    </p>
                    <p className="mt-3 text-sm leading-8 text-slate-700 dark:text-slate-300">
                      {typeof currentFlashcard === "object" && currentFlashcard
                        ? "back" in currentFlashcard
                          ? String(currentFlashcard.back)
                          : JSON.stringify(currentFlashcard)
                        : String(currentFlashcard)}
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap gap-3">
                <button
                  type="button"
                  onClick={onPrevFlashcard}
                  className="inline-flex items-center gap-2 rounded-2xl border border-slate-300 bg-white px-4 py-3 text-sm font-semibold text-slate-700 transition hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100 dark:hover:bg-slate-800"
                >
                  <ChevronLeft className="h-4 w-4" />
                  Poprzednia
                </button>

                <button
                  type="button"
                  onClick={onNextFlashcard}
                  className="inline-flex items-center gap-2 rounded-2xl bg-slate-950 px-4 py-3 text-sm font-semibold text-white transition hover:opacity-90 dark:bg-white dark:text-slate-950"
                >
                  Następna
                  <ChevronRight className="h-4 w-4" />
                </button>
              </div>
            </>
          ) : (
            <div className="rounded-[24px] border border-dashed border-slate-300 bg-slate-50 p-10 text-center dark:border-slate-700 dark:bg-slate-950">
              <p className="text-sm text-slate-600 dark:text-slate-300">Brak fiszek.</p>
            </div>
          )}
        </section>
      ) : null}

      {showQuiz ? (
        <section className="space-y-4">
          <div className="rounded-[24px] border border-slate-200 bg-slate-50 p-5 dark:border-slate-800 dark:bg-slate-950">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <p className="text-sm font-semibold text-slate-800 dark:text-slate-100">
                Odpowiedziano: {answeredCount} / {quiz.length}
              </p>
              <p className="text-sm font-semibold text-slate-800 dark:text-slate-100">
                Wynik: {quizScore}
              </p>
            </div>
          </div>

          {quiz.length > 0 ? (
            quiz.map((item, index) => {
              const question =
                item && typeof item === "object" && "question" in item
                  ? String(item.question)
                  : `Pytanie ${index + 1}`;

              const options =
                item && typeof item === "object" && "options" in item && Array.isArray(item.options)
                  ? item.options.map(String)
                  : [];

              const correctAnswer =
                item && typeof item === "object" && "answer" in item
                  ? String(item.answer)
                  : "";

              const selected = selectedAnswers[index];

              return (
                <div
                  key={`${question}-${index}`}
                  className="rounded-[24px] border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-950"
                >
                  <p className="text-sm font-semibold uppercase tracking-[0.18em] text-slate-500 dark:text-slate-400">
                    Pytanie {index + 1}
                  </p>
                  <h4 className="mt-2 text-base font-bold text-slate-950 dark:text-slate-100">
                    {question}
                  </h4>

                  <div className="mt-4 space-y-3">
                    {options.map((option) => {
                      const active = selected === option;
                      const shouldMarkCorrect = showAnswers && option === correctAnswer;
                      const shouldMarkWrong =
                        showAnswers && active && option !== correctAnswer;

                      return (
                        <button
                          key={option}
                          type="button"
                          onClick={() => onSetSelectedAnswer(index, option)}
                          className={`block w-full rounded-2xl border px-4 py-3 text-left text-sm transition ${
                            shouldMarkCorrect
                              ? "border-emerald-300 bg-emerald-50 text-emerald-800 dark:border-emerald-900/40 dark:bg-emerald-950/30 dark:text-emerald-300"
                              : shouldMarkWrong
                              ? "border-rose-300 bg-rose-50 text-rose-800 dark:border-rose-900/40 dark:bg-rose-950/30 dark:text-rose-300"
                              : active
                              ? "border-slate-950 bg-slate-950 text-white dark:border-white dark:bg-white dark:text-slate-950"
                              : "border-slate-300 bg-white text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 dark:hover:bg-slate-800"
                          }`}
                        >
                          {option}
                        </button>
                      );
                    })}
                  </div>

                  {showAnswers ? (
                    <p className="mt-4 text-sm text-slate-600 dark:text-slate-300">
                      Poprawna odpowiedź: <strong>{correctAnswer}</strong>
                    </p>
                  ) : null}
                </div>
              );
            })
          ) : (
            <div className="rounded-[24px] border border-dashed border-slate-300 bg-slate-50 p-10 text-center dark:border-slate-700 dark:bg-slate-950">
              <p className="text-sm text-slate-600 dark:text-slate-300">Brak quizu.</p>
            </div>
          )}

          <div className="flex flex-wrap gap-3">
            <button
              type="button"
              onClick={onSubmitQuiz}
              className="rounded-2xl bg-slate-950 px-5 py-3 text-sm font-semibold text-white transition hover:opacity-90 dark:bg-white dark:text-slate-950"
            >
              Sprawdź quiz
            </button>

            <button
              type="button"
              onClick={onToggleShowAnswers}
              className="rounded-2xl border border-slate-300 bg-white px-5 py-3 text-sm font-semibold text-slate-700 transition hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100 dark:hover:bg-slate-800"
            >
              {showAnswers ? "Ukryj odpowiedzi" : "Pokaż odpowiedzi"}
            </button>

            <button
              type="button"
              onClick={onResetQuiz}
              className="rounded-2xl border border-slate-300 bg-white px-5 py-3 text-sm font-semibold text-slate-700 transition hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100 dark:hover:bg-slate-800"
            >
              Reset quizu
            </button>
          </div>
        </section>
      ) : null}

      {showStudyPlan ? (
        <section className="space-y-4">
          {studyPlan.length > 0 ? (
            studyPlan.map((step, index) => (
              <div
                key={`${String(step)}-${index}`}
                className="rounded-[24px] border border-slate-200 bg-slate-50 p-5 dark:border-slate-800 dark:bg-slate-950"
              >
                <p className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-500 dark:text-slate-400">
                  Krok {index + 1}
                </p>
                <p className="mt-3 text-sm leading-8 text-slate-700 dark:text-slate-300">
                  {typeof step === "string" ? step : JSON.stringify(step)}
                </p>
              </div>
            ))
          ) : (
            <div className="rounded-[24px] border border-dashed border-slate-300 bg-slate-50 p-10 text-center dark:border-slate-700 dark:bg-slate-950">
              <p className="text-sm text-slate-600 dark:text-slate-300">Brak planu nauki.</p>
            </div>
          )}
        </section>
      ) : null}
    </div>
  );
}
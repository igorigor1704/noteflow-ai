"use client";

import Link from "next/link";
import { Heart, Pin } from "lucide-react";
import type { LibraryAnalysis } from "../_lib/library";

type Props = {
  analysis: LibraryAnalysis;
  onTogglePinned: () => void;
  onToggleFavorite: () => void;
};

function formatDate(value?: string) {
  if (!value) return "Brak daty";

  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;

  return date.toLocaleDateString("pl-PL", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
}

export default function LibraryAnalysisCard({
  analysis,
  onTogglePinned,
  onToggleFavorite,
}: Props) {
  const tags = Array.isArray(analysis.tags) ? analysis.tags : [];
  const keywords = Array.isArray(analysis.keywords) ? analysis.keywords : [];

  return (
    <article className="rounded-[24px] border border-slate-200 bg-slate-50 p-5 transition hover:border-slate-300 dark:border-slate-800 dark:bg-slate-950 dark:hover:border-slate-700">
      <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
        <div className="min-w-0 flex-1">
          <div className="mb-2 flex flex-wrap items-center gap-2">
            <span className="rounded-full border border-slate-200 bg-white px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.18em] text-slate-500 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-400">
              {formatDate(analysis.createdAt)}
            </span>

            {analysis.isPinned ? (
              <span className="rounded-full border border-slate-200 bg-white px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.18em] text-slate-500 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-400">
                Przypięte
              </span>
            ) : null}

            {analysis.isFavorite ? (
              <span className="rounded-full border border-slate-200 bg-white px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.18em] text-slate-500 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-400">
                Ulubione
              </span>
            ) : null}
          </div>

          <h3 className="truncate text-lg font-bold text-slate-950 dark:text-slate-100">
            {analysis.title || "Bez tytułu"}
          </h3>

          <p className="mt-2 line-clamp-3 text-sm leading-7 text-slate-600 dark:text-slate-300">
            {analysis.summary || "Brak podsumowania dla tej analizy."}
          </p>

          {tags.length > 0 ? (
            <div className="mt-3 flex flex-wrap gap-2">
              {tags.slice(0, 6).map((tag) => (
                <span
                  key={`${analysis.id}-${tag}`}
                  className="rounded-full border border-slate-200 bg-white px-3 py-1 text-xs text-slate-600 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300"
                >
                  #{tag}
                </span>
              ))}
            </div>
          ) : null}

          {keywords.length > 0 ? (
            <div className="mt-3 text-xs text-slate-500 dark:text-slate-400">
              Słowa kluczowe: {keywords.slice(0, 4).join(", ")}
            </div>
          ) : null}
        </div>

        <div className="flex flex-wrap gap-2 lg:justify-end">
          <Link
            href={`/dashboard/analysis/${analysis.id}`}
            className="rounded-2xl bg-slate-950 px-4 py-2.5 text-sm font-semibold text-white transition hover:opacity-90 dark:bg-white dark:text-slate-950"
          >
            Otwórz
          </Link>

          <button
            type="button"
            onClick={onTogglePinned}
            className="inline-flex items-center gap-2 rounded-2xl border border-slate-300 bg-white px-4 py-2.5 text-sm font-semibold text-slate-700 transition hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 dark:hover:bg-slate-800"
          >
            <Pin className="h-4 w-4" />
            Pin
          </button>

          <button
            type="button"
            onClick={onToggleFavorite}
            className="inline-flex items-center gap-2 rounded-2xl border border-slate-300 bg-white px-4 py-2.5 text-sm font-semibold text-slate-700 transition hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 dark:hover:bg-slate-800"
          >
            <Heart className="h-4 w-4" />
            Like
          </button>
        </div>
      </div>
    </article>
  );
}
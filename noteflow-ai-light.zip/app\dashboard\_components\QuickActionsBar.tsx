"use client";

import type { ReactNode } from "react";
import { ArrowRight, Download, FileText, History, RotateCcw } from "lucide-react";

type Props = {
  hasResult: boolean;
  hasHistory: boolean;
  hasDueCards: boolean;
  onAnalyze: () => void;
  onExportTxt: () => void;
  onExportCsv: () => void;
  onScrollToHistory: () => void;
  onScrollToReview: () => void;
};

type ActionButtonProps = {
  label: string;
  icon: ReactNode;
  onClick: () => void;
  disabled?: boolean;
};

function SecondaryActionButton({
  label,
  icon,
  onClick,
  disabled = false,
}: ActionButtonProps) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      className="inline-flex items-center justify-center gap-2 rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-700 transition hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-40 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 dark:hover:bg-slate-800"
    >
      {icon}
      {label}
    </button>
  );
}

export default function QuickActionsBar({
  hasResult,
  hasHistory,
  hasDueCards,
  onAnalyze,
  onExportTxt,
  onExportCsv,
  onScrollToHistory,
  onScrollToReview,
}: Props) {
  return (
    <section className="overflow-hidden rounded-[30px] border border-slate-200/80 bg-white/95 shadow-[0_18px_60px_rgba(15,23,42,0.06)] backdrop-blur-sm dark:border-slate-800 dark:bg-slate-900/95">
      <div className="border-b border-slate-100 px-6 py-5 dark:border-slate-800">
        <div className="flex flex-col gap-5 xl:flex-row xl:items-center xl:justify-between">
          <div className="max-w-2xl">
            <p className="text-sm font-semibold uppercase tracking-[0.18em] text-slate-400">
              Workspace
            </p>
            <h2 className="mt-2 text-2xl font-bold tracking-tight text-slate-950 dark:text-slate-100">
              Najważniejsze akcje na start
            </h2>
            <p className="mt-2 text-sm leading-7 text-slate-600 dark:text-slate-300">
              Najpierw wygeneruj analizę, potem przejdź do zapisanych materiałów
              albo od razu wróć do dzisiejszych powtórek.
            </p>
          </div>

          <button
            type="button"
            onClick={onAnalyze}
            className="inline-flex items-center justify-center gap-2 rounded-2xl bg-slate-950 px-5 py-3 text-sm font-bold text-white transition hover:opacity-90 dark:bg-white dark:text-slate-950"
          >
            Generuj analizę
            <ArrowRight className="h-4 w-4" />
          </button>
        </div>
      </div>

      <div className="grid gap-4 px-6 py-5 md:grid-cols-2 xl:grid-cols-4">
        <div className="rounded-[24px] border border-slate-200 bg-slate-50 p-4 dark:border-slate-800 dark:bg-slate-950">
          <div className="flex items-center gap-2 text-sm font-semibold text-slate-900 dark:text-slate-100">
            <Download className="h-4 w-4" />
            Eksport materiału
          </div>
          <p className="mt-2 text-sm leading-6 text-slate-600 dark:text-slate-300">
            Zapisz wynik analizy i fiszki, gdy chcesz wykorzystać materiał poza aplikacją.
          </p>

          <div className="mt-4 flex flex-wrap gap-2">
            <SecondaryActionButton
              label="Eksport TXT"
              icon={<FileText className="h-4 w-4" />}
              onClick={onExportTxt}
              disabled={!hasResult}
            />
            <SecondaryActionButton
              label="Eksport CSV"
              icon={<Download className="h-4 w-4" />}
              onClick={onExportCsv}
              disabled={!hasResult}
            />
          </div>
        </div>

        <div className="rounded-[24px] border border-slate-200 bg-slate-50 p-4 dark:border-slate-800 dark:bg-slate-950">
          <div className="flex items-center gap-2 text-sm font-semibold text-slate-900 dark:text-slate-100">
            <History className="h-4 w-4" />
            Biblioteka analiz
          </div>
          <p className="mt-2 text-sm leading-6 text-slate-600 dark:text-slate-300">
            Wróć do poprzednich materiałów, jeśli chcesz kontynuować naukę lub
            odświeżyć starszą analizę.
          </p>

          <div className="mt-4">
            <SecondaryActionButton
              label="Przejdź do historii"
              icon={<History className="h-4 w-4" />}
              onClick={onScrollToHistory}
              disabled={!hasHistory}
            />
          </div>
        </div>

        <div className="rounded-[24px] border border-slate-200 bg-slate-50 p-4 dark:border-slate-800 dark:bg-slate-950">
          <div className="flex items-center gap-2 text-sm font-semibold text-slate-900 dark:text-slate-100">
            <RotateCcw className="h-4 w-4" />
            Dzisiejsze powtórki
          </div>
          <p className="mt-2 text-sm leading-6 text-slate-600 dark:text-slate-300">
            Otwórz karty do powtórki i wróć do spaced repetition bez szukania ich ręcznie.
          </p>

          <div className="mt-4">
            <SecondaryActionButton
              label="Przejdź do powtórek"
              icon={<RotateCcw className="h-4 w-4" />}
              onClick={onScrollToReview}
              disabled={!hasDueCards}
            />
          </div>
        </div>

        <div className="rounded-[24px] border border-slate-200 bg-gradient-to-br from-slate-950 to-slate-800 p-4 text-white dark:border-slate-700">
          <p className="text-sm font-semibold uppercase tracking-[0.16em] text-white/70">
            Flow
          </p>
          <h3 className="mt-2 text-lg font-bold">
            Materiał → analiza → biblioteka → powtórka
          </h3>
          <p className="mt-2 text-sm leading-6 text-white/80">
            Dashboard ma prowadzić Cię przez kolejne kroki nauki, a nie tylko pokazywać funkcje.
          </p>
        </div>
      </div>
    </section>
  );
}
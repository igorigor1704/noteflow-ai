"use client";

type ActivityDay =
  | string
  | {
      date: string;
      count: number;
    };

type DashboardSidebarProps = {
  focusSeconds?: number;
  focusRunning?: boolean;
  reminderMinutes?: string;
  progressToNextLevel?: number;
  achievementBadges?: string[];
  activityDays?: ActivityDay[];
  onToggleFocus?: () => void;
  onResetFocus?: () => void;
  onReminderMinutesChange?: (value: string) => void;
  onEnableNotifications?: () => void;
  onScheduleReminder?: () => void;
};

export default function DashboardSidebar({
  focusSeconds = 0,
  focusRunning = false,
  reminderMinutes = "25",
  progressToNextLevel = 0,
  achievementBadges = [],
  activityDays = [],
  onToggleFocus = () => {},
  onResetFocus = () => {},
  onReminderMinutesChange = () => {},
  onEnableNotifications = () => {},
  onScheduleReminder = () => {},
}: DashboardSidebarProps) {
  const normalizedDays = (Array.isArray(activityDays) ? activityDays : []).map((day) =>
    typeof day === "string" ? { date: day, count: 0 } : day
  );

  const progressPercent = Math.max(
    0,
    Math.min(100, Math.round((progressToNextLevel || 0) * 100))
  );

  return (
    <aside className="space-y-8">
      <section className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900">
        <h2 className="mb-4 text-2xl font-semibold text-slate-950 dark:text-slate-100">
          Focus & przypomnienia
        </h2>

        <div className="mb-4 rounded-2xl bg-slate-100 p-5 dark:bg-slate-800">
          <p className="mb-2 text-sm text-slate-500 dark:text-slate-400">
            Focus timer
          </p>
          <p className="text-4xl font-bold text-slate-950 dark:text-slate-100">
            {String(Math.floor(focusSeconds / 60)).padStart(2, "0")}:
            {String(focusSeconds % 60).padStart(2, "0")}
          </p>

          <div className="mt-4 flex flex-wrap gap-2">
            <button
              type="button"
              onClick={onToggleFocus}
              className="rounded-xl bg-slate-950 px-4 py-2 text-sm font-medium text-white dark:bg-white dark:text-slate-950"
            >
              {focusRunning ? "Pauza" : "Start"}
            </button>

            <button
              type="button"
              onClick={onResetFocus}
              className="rounded-xl border border-slate-300 bg-white px-4 py-2 text-sm font-medium text-slate-700 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
            >
              Reset
            </button>
          </div>
        </div>

        <div className="space-y-3">
          <input
            type="number"
            min="1"
            value={reminderMinutes}
            onChange={(e) => onReminderMinutesChange(e.target.value)}
            className="w-full rounded-2xl border border-slate-300 bg-slate-50 px-4 py-3 text-slate-900 outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            placeholder="Minuty do przypomnienia"
          />

          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={onEnableNotifications}
              className="rounded-xl border border-slate-300 bg-white px-4 py-2 text-sm font-medium text-slate-700 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
            >
              Włącz powiadomienia
            </button>

            <button
              type="button"
              onClick={onScheduleReminder}
              className="rounded-xl border border-slate-300 bg-white px-4 py-2 text-sm font-medium text-slate-700 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
            >
              Ustaw przypomnienie
            </button>
          </div>
        </div>
      </section>

      <section className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900">
        <h2 className="mb-4 text-2xl font-semibold text-slate-950 dark:text-slate-100">
          Postęp i osiągnięcia
        </h2>

        <div className="mb-4">
          <div className="mb-2 flex items-center justify-between text-sm text-slate-500 dark:text-slate-400">
            <span>Progres do kolejnego levelu</span>
            <span>{progressPercent}%</span>
          </div>
          <div className="h-3 rounded-full bg-slate-200 dark:bg-slate-800">
            <div
              className="h-3 rounded-full bg-slate-950 transition-all dark:bg-white"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>

        <div className="mb-4">
          <p className="mb-3 text-sm text-slate-500 dark:text-slate-400">
            Osiągnięcia
          </p>
          <div className="flex flex-wrap gap-2">
            {achievementBadges.length > 0 ? (
              achievementBadges.map((badge) => (
                <span
                  key={badge}
                  className="rounded-full border border-slate-300 bg-slate-50 px-3 py-1 text-sm text-slate-700 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
                >
                  {badge}
                </span>
              ))
            ) : (
              <span className="text-sm text-slate-500 dark:text-slate-400">
                Brak osiągnięć jeszcze.
              </span>
            )}
          </div>
        </div>

        <div>
          <p className="mb-3 text-sm text-slate-500 dark:text-slate-400">
            Aktywność 14 dni
          </p>
          <div className="grid grid-cols-7 gap-2">
            {normalizedDays.length > 0 ? (
              normalizedDays.map((day) => (
                <div
                  key={day.date}
                  title={`${day.date}: ${day.count}`}
                  className="aspect-square rounded-xl border border-slate-200 bg-slate-100 dark:border-slate-700 dark:bg-slate-800"
                  style={{
                    opacity:
                      day.count === 0 ? 0.25 : Math.min(1, 0.25 + day.count * 0.18),
                  }}
                />
              ))
            ) : (
              Array.from({ length: 14 }).map((_, index) => (
                <div
                  key={`empty-${index}`}
                  className="aspect-square rounded-xl border border-slate-200 bg-slate-100 opacity-25 dark:border-slate-700 dark:bg-slate-800"
                />
              ))
            )}
          </div>
        </div>
      </section>
    </aside>
  );
}
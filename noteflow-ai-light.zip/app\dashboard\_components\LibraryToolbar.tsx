"use client";

import type { LibraryFolder, LibrarySortOption } from "../_lib/library";

type Props = {
  search: string;
  onSearchChange: (value: string) => void;
  sortBy: LibrarySortOption;
  onSortChange: (value: LibrarySortOption) => void;
  folders: LibraryFolder[];
  activeFolderId: string;
  onFolderChange: (value: string) => void;
  tags: string[];
  activeTag: string;
  onTagChange: (value: string) => void;
};

const sortOptions: Array<{ value: LibrarySortOption; label: string }> = [
  { value: "newest", label: "Najnowsze" },
  { value: "oldest", label: "Najstarsze" },
  { value: "title-asc", label: "A → Z" },
  { value: "title-desc", label: "Z → A" },
  { value: "favorites", label: "Ulubione" },
  { value: "pinned", label: "Przypięte" },
];

export default function LibraryToolbar({
  search,
  onSearchChange,
  sortBy,
  onSortChange,
  folders,
  activeFolderId,
  onFolderChange,
  tags,
  activeTag,
  onTagChange,
}: Props) {
  const safeFolders = Array.isArray(folders) ? folders : [];
  const safeTags = Array.isArray(tags) ? tags : [];

  return (
    <section className="rounded-[28px] border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
      <div className="grid gap-5 xl:grid-cols-[1.2fr_0.8fr]">
        <div className="space-y-4">
          <div>
            <label className="mb-2 block text-sm font-semibold text-slate-700 dark:text-slate-200">
              Szukaj analizy
            </label>
            <input
              type="text"
              value={search}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="Szukaj po tytule, summary albo słowach kluczowych..."
              className="w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-slate-900 focus:ring-4 focus:ring-slate-200 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100 dark:focus:border-white dark:focus:ring-slate-800"
            />
          </div>

          <div>
            <p className="mb-2 text-sm font-semibold text-slate-700 dark:text-slate-200">
              Folder
            </p>
            <div className="flex flex-wrap gap-2">
              {safeFolders.map((folder) => (
                <button
                  key={folder.id}
                  type="button"
                  onClick={() => onFolderChange(folder.id)}
                  className={`rounded-full px-3 py-2 text-sm font-medium transition ${
                    activeFolderId === folder.id
                      ? "bg-slate-900 text-white dark:bg-white dark:text-slate-950"
                      : "border border-slate-200 bg-white text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100 dark:hover:bg-slate-800"
                  }`}
                >
                  {folder.name}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <label className="mb-2 block text-sm font-semibold text-slate-700 dark:text-slate-200">
              Sortowanie
            </label>
            <select
              value={sortBy}
              onChange={(e) => onSortChange(e.target.value as LibrarySortOption)}
              className="w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-900 outline-none transition focus:border-slate-900 focus:ring-4 focus:ring-slate-200 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100 dark:focus:border-white dark:focus:ring-slate-800"
            >
              {sortOptions.map((option) => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          </div>

          <div>
            <p className="mb-2 text-sm font-semibold text-slate-700 dark:text-slate-200">
              Tagi
            </p>
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => onTagChange("all")}
                className={`rounded-full px-3 py-2 text-sm font-medium transition ${
                  activeTag === "all"
                    ? "bg-slate-900 text-white dark:bg-white dark:text-slate-950"
                    : "border border-slate-200 bg-white text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100 dark:hover:bg-slate-800"
                }`}
              >
                Wszystkie
              </button>

              {safeTags.map((tag, index) => (
                <button
                  key={`${tag}-${index}`}
                  type="button"
                  onClick={() => onTagChange(tag)}
                  className={`rounded-full px-3 py-2 text-sm font-medium transition ${
                    activeTag === tag
                      ? "bg-slate-900 text-white dark:bg-white dark:text-slate-950"
                      : "border border-slate-200 bg-white text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100 dark:hover:bg-slate-800"
                  }`}
                >
                  #{tag}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}